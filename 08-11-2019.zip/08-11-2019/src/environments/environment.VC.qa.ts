export const environment = {
    applicationName: 'VIMS Converter',
    urlConfiguration: 'qaUrlConfig',
    production: false,
    baseUrl: 'http://localhost:9076/ngsite/',
    stompUrl: 'http://localhost:9076/',
    fedLogInUrls: {
        'catBaseUrl': 'https://fedloginqa.cat.com',
        'catRegisterUrl': 'https://registerhaq.rd.cat.com/',
        'userInfo': 'https://fedloginqa.cat.com/idp/userinfo.openid'
    },
    dspUrls: {
        'getDealers': 'https://dspappservice-qa.azurewebsites.net/api/asset/getDealers'
    },
    updateRedirectURL: 'https://dealer.cat.com/en/home.html',
    pingUrls: {
        'SITE_1': 'www.google.com',
        'SITE_2': 'www.github.com'
    }
};
