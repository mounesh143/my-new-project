export const environment = {
  applicationName: 'NGSiteSolution',
  urlConfiguration: 'prodUrlConfig',
  production: true,
  baseUrl: 'http://localhost:9076/ngsite/',
  stompUrl: 'http://localhost:9076/',
  loginUrl : 'http://localhost:9076/',
  fedLogInUrls: {
    'catBaseUrl': 'https://fedlogin.cat.com',
    'catRegisterUrl': 'https://registerhaq.rd.cat.com/',
    'userInfo': 'https://fedlogin.cat.com/idp/userinfo.openid'
  },
  dspUrls: {
    'getDealers': 'https://dspappservice.azurewebsites.net/api/asset/getDealers'
  },
  updateRedirectURL: 'https://dealer.cat.com/en/home.html',
  pingUrls: {
    'SITE_1': 'www.google.com',
    'SITE_2': 'www.github.com'
  }
};
