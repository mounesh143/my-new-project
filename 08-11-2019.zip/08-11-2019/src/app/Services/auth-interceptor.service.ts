import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { from } from 'rxjs/observable/from';
import { Observable, } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { _throw as throwError } from 'rxjs/observable/throw';
import { SuccessStatusMessage } from '@app/success.service';
import { CommonService } from '@app/common.service';
@Injectable()
export class AuthInterceptorService implements HttpInterceptor {

  constructor(private injector: Injector,private commonsService:CommonService,
              private  successStatusMessage: SuccessStatusMessage) { }

  handleError(error: HttpErrorResponse){
    this.showpopup('success', 'Internal Server Error')
    return throwError(error);
   }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let authService = this.injector.get(AuthenticationService)
    let userInfo = authService.getLoginInfoDetails();
    if (req.url.includes('/login')) {
      return next.handle(req).pipe(
        catchError(this.handleError),
       
        
       );
    }
    req = req.clone({
      setHeaders: {
        Authorization: userInfo['token'],
        OID: userInfo['oid'].toString()
      }
    });
    return next.handle(req).pipe(
      catchError(this.handleError)
     );

  }
  showpopup(type, errorMsg) {
    switch (type) {
      case 'success':
        this.successStatusMessage.statusSuccess(errorMsg);
        break;
     
    }
  }
}
