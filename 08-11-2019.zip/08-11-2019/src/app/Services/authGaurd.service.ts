import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from './authentication.service';
import { Observable } from 'rxjs/Observable';

@Injectable()

export class AuthGuard implements CanActivate  {

    constructor(private router: Router,private authService:AuthenticationService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      let user = sessionStorage.getItem('userName');  
      if (user !== null && user !== undefined){
      return true;
        }else{
    this.router.navigate(['login']);
    return false;
        }
}

}