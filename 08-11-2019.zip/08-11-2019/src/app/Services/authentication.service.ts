import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { map, flatMap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from '@env/environment';
import { ApiConstants } from '@app/api.constants';
import { RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable()
export class AuthenticationService {
  loginUserInfo:any
  
  constructor(private http: HttpClient, private router: Router) { }

    authenticate(username:string, password:string) {
      const loginUrl = environment.loginUrl + ApiConstants.getAPI('getLogin');
     //{ observe: 'response' as 'body'}
      let enCodePassword = btoa(password)
      return this.http.post<any>(loginUrl,
        {userName: username, password: enCodePassword },{'headers' : new HttpHeaders ({'Content-Type': 'application/json','No-Auth':'True' }), withCredentials: true ,observe:'response' as 'body'})
        .pipe(
          map(res => {
            sessionStorage.setItem('userName', username);
            localStorage.setItem('userInfo', JSON.stringify(res.body)); 
            return res.body;
        },error =>{
          return error;
        }));
    }
 
    isUserLoggedIn() {
      let user = sessionStorage.getItem('userName');
      if(user !== null || user !== undefined ) {
        return user
      }else
      return  false
    }

    logOut() {
     let oid =  this.loginUserInfo['oid'].toString();
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          
        }),
      }
      const loginUrl = environment.loginUrl + ApiConstants.getAPI('getLogOff');
      let body='' ;
       return this.http.post<any>(loginUrl,JSON.stringify(body), httpOptions)
         .pipe(
           map(res => {
            this.router.navigate(['login']);
            return res.body;
         },
         error=>{
          this.router.navigate(['login']);
           console.log(error);
         }
         ));
  }

  getLoginInfoDetails(){
    return this.loginUserInfo = JSON.parse(localStorage.getItem('userInfo'));
  }

 


}