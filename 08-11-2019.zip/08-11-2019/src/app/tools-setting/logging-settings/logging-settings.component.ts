import { Component, OnInit, ViewChild, Output, EventEmitter, OnDestroy } from '@angular/core';
import { SettingsService } from '../settings.service';
import { AppConstants } from '@app/app.constants';
import { ModelInterruptService } from '@app/modelInterrupt.service';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-logging-settings',
  templateUrl: './logging-settings.component.html',
  styleUrls: ['./logging-settings.component.scss']
})
export class LoggingSettingsComponent implements OnInit, OnDestroy {

  @ViewChild('settingsLoggingForm') templateForm: any;
  @Output() onChildPrefChanged: EventEmitter<any> = new EventEmitter();
  filePath = '';
  pref: any = {};
  unMergedPath: string;
  backUpPath: string;
  firstIndex;
  secIndex;
  showTexBox: boolean = true;
  resetValue;
  constructor(public settingsService: SettingsService,private modelInterruptService: ModelInterruptService) {
    this.getDataReadyEvent();
  }

  getDataReadyEvent() {
    this.settingsService.getDataReadyEvent().subscribe(() => {
      this.onSettingsDataAvailable();
    });
  }

  subscribeToTemplateValueChanges() {
    this.templateForm.valueChanges.subscribe((value: any) => {
      
      if (this.templateForm.dirty )  {
        
        // this.onChildPrefChanged.emit(true);
      }
    });
  }

  ngOnInit() {
    this.onSettingsDataAvailable();
    this.subscribeToTemplateValueChanges();
  }

  onSettingsDataAvailable(): void {
    const settingsData = this.settingsService.$userPreferences;
    if (settingsData !== undefined) {
      this.pref = settingsData['defaultPaths'];
      this.resetValue = localStorage.getItem('getSettingsUI');
      
      
    } else {
      console.log('only for test code coverage');
    }
  }
 
  onChangeButton(i,j,item,EditedPath){
    this.firstIndex = i;
    this.secIndex = j;
  
    if(EditedPath !== ''){
      
      this.pref.settingsFilePathsUIBean.map((eachGroup) => {
        eachGroup.paths.map((eachItem) => {
          if(eachItem.id == item.id){
            this.showTexBox = true;
            eachItem.path = EditedPath
          }
        })
      });
     
    } 
  }
  onKeyUp(event) {
    if(event === ''){
      this.onChildPrefChanged.emit(true)
    }
}
  onRestForm(){
    this.showTexBox = false;
    let restorValue = JSON.parse(this.resetValue);
    this.pref = restorValue['defaultPaths'];
    console.log(this.pref)
   
  }
  changePath(path) {
    let unMergedPath: String = '';
    let backUpPath: String = '';
    this.updatePathChanges(path, this.filePath);
    // let selectedFile: any = (<HTMLInputElement>document.getElementById(path.id)).files[0];
    // console.log(selectedFile)
   
    
    // const selectedFilePath = selectedFile.path;
    
    // (<HTMLInputElement>document.getElementById(path.label)).value = selectedFilePath;
    // // Get Unmerged and backup path for checking

    // this.pref.settingsFilePathsUIBean.map((eachGroup) => {
    //   eachGroup.paths.map((eachItem) => {
    //     unMergedPath = (eachItem.id === AppConstants.getConstants('UNMERGEDFILES')) ? eachItem.path : unMergedPath;
    //     backUpPath = (eachItem.id === AppConstants.getConstants('BACKUPFILES')) ? eachItem.path : backUpPath;
    //   })
    // });
    // this.updatePathChanges(path,this.filePath);
    // (AppConstants.getConstants('UNMERGEDFILES') === path.id) ? this.validatePath(path, backUpPath, selectedFilePath)
    //   : (AppConstants.getConstants('BACKUPFILES') === path.id) ? this.validatePath(path, selectedFilePath, unMergedPath) :
    //     this.updatePathChanges(path, selectedFilePath);
  }

 
  validatePath(path, path1, path2) {
    (path1.toUpperCase().startsWith(path2.toUpperCase())) ? this.resetPath(path) :
      this.updatePathChanges(path, (<HTMLInputElement>document.getElementById(path.id)).files[0]['path'])
  }

 
  resetPath(path) {
    this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'),
      AppConstants.getConstants('INVALID_PATH'), true);
    (<HTMLInputElement>document.getElementById(path.label)).value = path.path;
  }

 
  updatePathChanges(path, selectedFilePath) {

    this.pref.settingsFilePathsUIBean.map((eachGroup) => {
      eachGroup.paths.map((eachItem) => {
        eachItem.path = (eachItem.id === path.id || selectedFilePath !== '')  ? selectedFilePath : eachItem.path;
      })
    })
    console.log(this.pref)
    this.onChildPrefChanged.emit();
  }

  ngOnDestroy(): void {
    this.settingsService.getDataReadyEvent().unsubscribe();
  }

}
