import { LoggingSettingsComponent } from "./logging-settings.component";
import { ComponentFixture, async, TestBed } from "@angular/core/testing";
import { MockBackend } from "@angular/http/testing";
import { FormsModule } from "@angular/forms";
import { HttpModule, Http, BaseRequestOptions } from "@angular/http";
import { RouterTestingModule } from "@angular/router/testing";
import { HttpHandler, HttpClient } from "@angular/common/http";
import { SettingsService } from "../settings.service";

import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { inject } from "@angular/core/src/render3";
import { ModelInterruptService } from "@app/modelInterrupt.service";


describe('LoggingSettingsComponent', () => {
  let component: LoggingSettingsComponent;
  let fixture: ComponentFixture<LoggingSettingsComponent>;
  let backend: MockBackend = null;
  // const settingsDataMock = new settingsDataMock();
  let settingsData;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoggingSettingsComponent],
      imports: [FormsModule, HttpModule, RouterTestingModule],
      providers: [HttpHandler, Http, MockBackend, BaseRequestOptions, SettingsService, HttpClient, ModelInterruptService, {
        provide: Http,
        useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
          return new Http(backendInstance, defaultOptions)
        },
        deps: [MockBackend, BaseRequestOptions]
      }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  // beforeEach(inject([MockBackend, SettingsService], (mockBackend: MockBackend, SettingsService, ModelInterruptService) => {
  //   /* timeoutInterval = jasmine.DEFAULT_TIMEOUT_INTERVAL;
  //   jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000000; */
  //   fixture = TestBed.createComponent(LoggingSettingsComponent);
  //   component = fixture.componentInstance;
  //   backend = mockBackend;
  //   this.settingsService = SettingsService;
  //   this.modelInterruptService = ModelInterruptService;
  //   component.ngOnInit();
  //   component.ngOnDestroy();
  //   settingsData = settingsDataMock.getSettingsUI();
  //   fixture.detectChanges();
  // }));

  /* afterEach(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = timeoutInterval;
  })
 */
  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe to onSettingsDataAvailable if $userPreferences is defined', () => {
    spyOn(component, 'onSettingsDataAvailable').and.callThrough();
    component.settingsService.$userPreferences = { 'key': 'pair' };
    component.onSettingsDataAvailable();
    expect(component.settingsService.$userPreferences).toBeDefined();
  });

  it('should subscribe to onSettingsDataAvailable if $userPreferences not defined', () => {
    component.onSettingsDataAvailable();
    expect(component.settingsService.$userPreferences).not.toBeDefined();
  });

  it('should subscribe getDataReadyEvent', () => {
    component.getDataReadyEvent();
    component.settingsService.getDataReadyEvent().next();
  })

  it('shoul handle subscribeToTemplateValueChanges method', () => {
    component.subscribeToTemplateValueChanges();
    component.templateForm.valueChanges.next();
    /* const element: HTMLInputElement = document.getElementById('UnmergedFiles') as HTMLInputElement;
    element.setAttribute('value', 'test');
    fixture.detectChanges(); */
    spyOn(component.onChildPrefChanged, 'emit');
    component.onChildPrefChanged.emit();
    expect(component.onChildPrefChanged.emit).toHaveBeenCalled();
  })
});
