import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToolsSettingComponent } from './tools-setting.component';
import { LoggingSettingsComponent } from './logging-settings/logging-settings.component';
import { MergeSettingsComponent } from './merge-settings/merge-settings.component';
import { CatTogglebuttonComponent } from './cat-togglebutton.component';
import { ReportsSettingsComponent } from './reports-settings/reports-settings.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TabViewModule, RadioButtonModule, DropdownModule, SelectButtonModule, CheckboxModule, OverlayPanelModule, CalendarModule, AccordionModule, DialogModule, ProgressBarModule } from 'primeng/primeng';
import { SettingsService } from './settings.service';
import { PreferenceService } from './preference.service';

@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot([]),FormsModule,ReactiveFormsModule,
    TabViewModule, RadioButtonModule, DropdownModule, SelectButtonModule, CheckboxModule, OverlayPanelModule, CalendarModule, AccordionModule, DialogModule, ProgressBarModule
  ],
  declarations: [
    ToolsSettingComponent,
    LoggingSettingsComponent,
    MergeSettingsComponent,
    CatTogglebuttonComponent,
    ReportsSettingsComponent
  ],
  exports: [ToolsSettingComponent],
  providers:[SettingsService,PreferenceService],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
})
export class ToolsSettingModule { }
