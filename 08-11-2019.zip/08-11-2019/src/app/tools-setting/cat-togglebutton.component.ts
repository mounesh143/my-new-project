import { Component, Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'cat-togglebutton',
  template: `
  
  <div class="toggle_with_label">
  <span>{{label}}</span>
  <div class="toggle_switch" (click)="onToggle()" [ngClass]="{on:isOn, off:!isOn, toggle_disable:isDisabled}">&nbsp;</div>
</div>


  `,

  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => CatTogglebuttonComponent),
      multi: true
    }
  ]
})
export class CatTogglebuttonComponent implements ControlValueAccessor {

  @Input() trueLabel;
  @Input() falseLabel;
  label = '';
  isOn;
  isDisabled;
  @Output() emitToggleChange: EventEmitter<any> = new EventEmitter<any>();


  propagateChange = (_any: any) => { }

  constructor() { }

  onToggle() {
    this.isOn = !this.isOn;
    this.label = (this.isOn) ? this.trueLabel : this.falseLabel;
    this.propagateChange(this.isOn);
    this.emitToggleChange.emit(this.isOn);
  }

  writeValue(value: any) {
    if (value !== undefined && value !== null) {
      this.isOn = value;
      this.label = (this.isOn) ? this.trueLabel : this.falseLabel;
    }
  }

  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }


  registerOnTouched(fn: any): void { }

 
  setDisabledState(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }
}
