import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolsSettingComponent } from './tools-setting.component';
import { DataTableModule,DialogModule, SharedModule, CheckboxModule, PaginatorModule, TabViewModule, ToggleButtonModule, ProgressBarModule, OverlayPanelModule, AutoCompleteModule, RadioButtonModule, CalendarModule, SelectButtonModule, DropdownModule, AccordionModule } from 'primeng/primeng';
import { LoggingSettingsComponent } from './logging-settings/logging-settings.component';
import { MergeSettingsComponent } from './merge-settings/merge-settings.component';
import { ReportsSettingsComponent } from './reports-settings/reports-settings.component';
import { CatTogglebuttonComponent } from './cat-togglebutton.component';
import { SettingsService } from './settings.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ModelInterruptService } from '@app/modelInterrupt.service';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
describe('ToolsSettingComponent', () => {
  let component: ToolsSettingComponent;
  let fixture: ComponentFixture<ToolsSettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToolsSettingComponent,LoggingSettingsComponent,MergeSettingsComponent,
        ReportsSettingsComponent,CatTogglebuttonComponent ],
      imports:[DataTableModule,DialogModule, SharedModule, CheckboxModule,
         PaginatorModule, TabViewModule, ToggleButtonModule, ProgressBarModule,
          OverlayPanelModule, AutoCompleteModule, RadioButtonModule, CalendarModule,BrowserAnimationsModule,
           SelectButtonModule, DropdownModule, AccordionModule,BrowserModule,FormsModule,RouterModule,
           HttpClientModule,RouterTestingModule,],
      providers:[SettingsService,ModelInterruptService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToolsSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
