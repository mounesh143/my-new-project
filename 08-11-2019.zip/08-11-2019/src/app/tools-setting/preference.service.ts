import { CommonService } from '@app/common.service';
import { Injectable } from '@angular/core';

import { environment } from '@env/environment';
import { Subject } from 'rxjs/Subject';
import { AppConstants, ECM_TYPE, ApiConstants } from '@app/constants';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class PreferenceService {

  settingsPreferences: any
  preferredConnection: string;
  isAutoDetectEnabled: boolean;
  // isApiLoaded = false;
  private apiLoadedEvent: Subject<any> = new Subject();
  prefSubject = new Subject();
  toolSettings = new Subject();
  // loginToken = new Subject();
  /* Task 822 Vigneswar 22012018 starts */
  isDataLoggerVisbile = false;
  isSnapShotVisible = false;
  isBuffSizeProgressBarVisible = true;
  connectedEthernetMachineType = '';
  connectedECMName = '';
  /* Task 822 Vigneswar 22012018 ends */

  constructor(private http: HttpClient, private commonService: CommonService) { }

  getToolSettings(): Promise<object> {
    return new Promise((resolve) => {
      const toolSettingsUrl = environment.baseUrl + ApiConstants.getAPI('getToolSettings');
      this.http.get(toolSettingsUrl).subscribe((response: any) => {
        this.onSettingsDataAvailable(response);
        resolve();
      }, (error) => { console.log(' ERROR IN GET TOOL SETTINGS API'); });
    })
  }

  /**
   * @description Used to handle get tool settings api response
   * @author Vigneswar Chelliah
   * @param {any} response
   * @param {any} isValid
   * @memberof PreferenceService
   */
  onSettingsDataAvailable(response) {
    // this.isApiLoaded = true;
    localStorage.setItem(AppConstants.getConstants('USER_PREFERENCE'), JSON.stringify(response));
    this.preferredConnection = response.toolSettings.preferredConnection;
    this.prefSubject.next(true); // TODO : handle this
    this.toolSettings.next(true);
  }

  public getBootstrapEvent(): Subject<any> {
    if (!this.prefSubject || this.prefSubject.isStopped) {
      this.prefSubject = new Subject();
    }
    return this.prefSubject;
  }
  /**
   * @description Used to invoke the connectedMachineProperties API.
   * @author Vigneswar Chelliah
   * @memberof ConnectComponent
   */
  invokeConnectedMachinePropertiesAPI(): Promise<any> {
    return new Promise((resolve) => {
      this.commonService.invokeConnectedMacPropertiesAPI().subscribe((response) => {
        this.isDataLoggerVisbile = response['dataLoggerActivated'];
        this.isSnapShotVisible = response['snapshotActivated'];
        this.connectedEthernetMachineType = response['connectedType'].toString();
        this.connectedECMName = String(response['connectedECMName']).toLowerCase();
        this.isBuffSizeProgressBarVisible = (this.connectedEthernetMachineType === ECM_TYPE.A5.toString()) ? false : true;
        resolve();
      })
    })
  }
  /**
   * @description Used to get login credentials
   * @author Rajesh
   * @memberof PreferenceService
   */
  checkAuthorization() {
    const loginCrendialsurl = environment.baseUrl + ApiConstants.getAPI('checkAuthorization');
    return this.http.get(loginCrendialsurl); /* .subscribe((data: any) => {
      this.loginToken.next(data.result);
    }) */
  }

  /**
   * @description Used to get build update version details
   * @author Vigneswar Chelliah
   * @memberof UpgradeComponent
   */
  /* getUpdateVersionDetails() {
    this.commonService.getUpdateVersionDetails().subscribe((response) => {
      localStorage.setItem(AppConstants.getConstants('UPDATE_BUILD_INFO'), JSON.stringify(response));
    }, (error) => {
      console.log('error in response : ', error.status);
    })
  } */
}
