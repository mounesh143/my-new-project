
import { Injectable, Output, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { environment } from '@env/environment';
import 'rxjs/add/observable/forkJoin';
import { ApiConstants, AppConstants } from '@app/constants';


import { Http, Response, Headers, RequestOptions} from '@angular/http';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { SuccessStatusMessage } from '@app/success.service';

@Injectable()
export class SettingsService {

  /*private variable to store the user settings data received from API*/
  public userPreferences: any;

  public isSettingsPreferenceChanged = false;

  public saveSettingsPopupVisibility = false;

  public settingsPopupVisibilityEvent: Subject<any> = new Subject();
  prefSubject = new Subject();
  toolSettings = new Subject();
  preferredConnection: string;
  /*private variable to store the user settings data labels received from settings.json*/
  public staticUserPreferences: any;

  /*event emitter to notify whenever the API returns settings data*/
  public dataReadyEvent: Subject<any> = new Subject();

  /*event to nofity when navigate to another route withouting saving settings */
  public canActivateEvent: Subject<any> = new Subject();

  /*event to nofity when navigate among settings */
  private settingsTabEvent: Subject<any> = new Subject<any>();

  // private Event: Subject<any> =new Subject();
  @Output() public settingSavedEvent: EventEmitter<string> = new EventEmitter();


  constructor(private http: HttpClient,private  successStatusMessage: SuccessStatusMessage) { }

  public get $userPreferences(): object {
    return this.userPreferences;
  };


  public set $userPreferences(value: object) {
    this.userPreferences = value;
  };

  public get $staticUserPreferences(): object {
    return this.staticUserPreferences;
  };


  public set $staticUserPreferences(value: object) {
    this.staticUserPreferences = value;
  };

  public get $isSettingsPreferenceChanged(): boolean {
    return this.isSettingsPreferenceChanged;
  }

  public set $isSettingsPreferenceChanged(value: boolean) {
    this.isSettingsPreferenceChanged = value;
  }

  public get $saveSettingsPopupVisibility(): boolean {
    return this.saveSettingsPopupVisibility;
  }

  public set $saveSettingsPopupVisibility(value: boolean) {
    this.saveSettingsPopupVisibility = value;
  }


  getSettingsPreferences() {
    const getSettingsUrl = environment.baseUrl + ApiConstants.getAPI('getSettings');
    return this.http.get(getSettingsUrl);
  };

  getAdapterDetails() {
    const getAdapterDetailsUrl = environment.baseUrl + ApiConstants.getAPI('getAdapterDetails');
    return this.http.get(getAdapterDetailsUrl);
  }

  postSettingsPreferences(userPreferences) {
     
    const url = environment.baseUrl + ApiConstants.getAPI('saveSettings');
    return this.http.post(url, userPreferences);
  }

  postVerifyA6(ipAddress, adapterName) {
    const verifyUrl = environment.baseUrl + 'rtds/verifyA6?ipAddress=' + ipAddress + '&adapterName=' + adapterName;
    return this.http.get(verifyUrl)
  }


  public getDataReadyEvent(): Subject<any> {
    (this.dataReadyEvent.isStopped) ? this.dataReadyEvent = new Subject() : console.log('dataReadyEvent not stopped');
    return this.dataReadyEvent;
  };


  public onSettingsDataAvailable(): void {
    this.getDataReadyEvent().next();
  };

  public getsettingsPopupVisibilityEvent(): Subject<any> {
    (this.settingsPopupVisibilityEvent.isStopped) ?
      this.settingsPopupVisibilityEvent = new Subject() : console.log('settingsPopupVisibilityEvent not stopped');
    return this.settingsPopupVisibilityEvent;
  };

  public onSettingsPopupVisiblityChanged(): void {
    this.getsettingsPopupVisibilityEvent().next();
  };

  public getcanActivateEvent(): Subject<any> {
    (this.canActivateEvent.isStopped) ? this.canActivateEvent = new Subject() : console.log('canActivateEvent not stopped');
    return this.canActivateEvent;
  };

  public onRouteChanged(status): void {
    this.getcanActivateEvent().next(status);
  };

  getSettingSavedEvent(): EventEmitter<any> {
    return this.settingSavedEvent;
  }

  onSettingSavedEvent(): void {
    this.settingSavedEvent.emit();

  }


  setSettingsTabEvent(event) {
    this.settingsTabEvent.next(event);
  }
  get settingsTabEvents$() {
    return this.settingsTabEvent.asObservable();
  }

  getToolSettings(): Promise<object> {
    return new Promise((resolve) => {
      const toolSettingsUrl = environment.baseUrl + ApiConstants.getAPI('getToolSettings');
      this.http.get(toolSettingsUrl).subscribe((response: any) => {
        this.onSettingsDataAvailableValue(response);
        resolve();
      }, (error) => {  this.showpopup('success', 'Internal Server Error'); });
    })
  }
  onSettingsDataAvailableValue(response){
    localStorage.setItem(AppConstants.getConstants('USER_PREFERENCE'), JSON.stringify(response));
    this.preferredConnection = response.toolSettings.preferredConnection;
    this.prefSubject.next(true); // TODO : handle this
    this.toolSettings.next(true);
  }

  showpopup(type, errorMsg) {
    switch (type) {
      case 'success':
        this.successStatusMessage.statusSuccess(errorMsg);
        break;
     
    }
  }

}
