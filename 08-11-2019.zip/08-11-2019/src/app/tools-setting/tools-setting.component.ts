import { Component, OnInit, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { SettingsService } from './settings.service';
import { AppConstants } from '@app/app.constants';
import { CommonService } from '@app/common.service';
import { ModelInterruptService } from '@app/modelInterrupt.service';
import { SuccessStatusMessage } from '@app/success.service';
import { PreferenceService } from './preference.service';
import { MenuService } from '@app/menu.service';



@Component({
  selector: 'app-tools-setting',
  templateUrl: './tools-setting.component.html',
  styleUrls: ['./tools-setting.component.scss']
})
export class ToolsSettingComponent implements OnInit,AfterViewChecked {

  activeTab;
  saveSettingsPopupVisibility: any;
  tabs = [];
  isSettingsPreferenceChanged = false;
  settings: any;
  defaultPathsVisibility: boolean;
  display: boolean = false;
  changesUnsavedDialog = {
    'body': AppConstants.getConstants('CHANGE_UNSAVED_DIALOG_PHRASE'),
    'save': AppConstants.getConstants('CHANGE_UNSAVED_DIALOG_SAVE'),
    'discard': AppConstants.getConstants('CHANGE_UNSAVED_DIALOG_DISCARD')
  };
  isSettingClosedInPopup = false;
  constructor(private cdRef: ChangeDetectorRef,private settingsInterface:SettingsService,private commonService: CommonService,private modelInterruptService: ModelInterruptService,
    private  successStatusMessage: SuccessStatusMessage, private preference: PreferenceService,private menuService: MenuService
    ) { }

  ngOnInit() {
    this.onInit();
  };

  onInit() {
    
   
    this.getAPICall();
 
  }

  getAPICall(){
    this.saveSettingsPopupVisibility = this.settingsInterface.$saveSettingsPopupVisibility;
    this.settingsInterface.getSettingsPreferences().subscribe((settings) => {
      localStorage.setItem(AppConstants.getConstants('GET_SETTINGS_UI'), JSON.stringify(settings));
      this.settings = settings;
      this.defaultPathsVisibility = this.settings.defaultPaths.visibility;
      this.onSettingsDataReady(settings);
     
    },error =>{
      this.showpopup('success', 'Internal Server Error');
    }
    );
    this.settingsInterface.getsettingsPopupVisibilityEvent().subscribe(() => {
      this.saveSettingsPopupVisibility = this.settingsInterface.$saveSettingsPopupVisibility;
    }, () => { })
    this.settingsInterface.getToolSettings();
  }

  onPrefChanged(bool): void {
    console.log(bool)
    this.isSettingsPreferenceChanged = (bool || bool === undefined) ? true : false;
    this.settingsInterface.$isSettingsPreferenceChanged = this.isSettingsPreferenceChanged;
  }
 
  onSettingsDataReady(data): void {
    this.settingsInterface.$userPreferences = data;
    this.settingsInterface.onSettingsDataAvailable();
  }

  updateActiveTab(number: Number): void {
    if (this.commonService.settingActiveTab) {
      this.commonService.settingActiveTab = !this.commonService.settingActiveTab;
      this.activeTab = number;
    } else {
      this.activeTab = 0;
    }
  }
  onSave(isBool = false): void {
  
    this.isSettingClosedInPopup = isBool;
    const settings = this.settingsInterface.$userPreferences;
    this.display = true;
    
    
    if (Number(settings['dataProcessing'].fileWatcherInterval) < AppConstants.getConstants('MERGE_MIN_FREQUENCY') ||
      Number(settings['dataProcessing'].fileWatcherInterval) > AppConstants.getConstants('MERGE_MAX_FREQUENCY')) {
      this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'),
        AppConstants.getConstants('MERGE_FREQUENCY_WARNING_1'));
      return;
    }
    this.saveSettings();
  }

  saveSettings() {
    this.settingsInterface.postSettingsPreferences(this.settingsInterface.$userPreferences).subscribe((data) => {
      this.settingsInterface.$isSettingsPreferenceChanged = this.isSettingsPreferenceChanged;
      console.log(data)
      // this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_SUCCESS'),
      //   'Your settings have been successfully updated!', true);
      if(data['responseMessage'] ===  "success"){
        if(this.display) { this.showpopup('success', 'Your settings have been successfully updated!'); }
        this.settingsInterface.onSettingSavedEvent();
        this.getAPICall();
        this.preference.getToolSettings().then(() => {
          this.onDiscard();
        });
      }else{
        if(this.display) { this.showpopup('success', 'Your settings have been Failed !!!'); }
        this.settingsInterface.onSettingSavedEvent();
        this.getAPICall();
      }
     
    },error =>{
      this.showpopup('success', 'Your settings have been Failed!!!!');
    });
  }

  onDiscard(isBool = false) {
    this.isSettingClosedInPopup = (isBool) ? isBool : this.isSettingClosedInPopup;
    this.settingsInterface.$isSettingsPreferenceChanged = this.isSettingsPreferenceChanged = false;
    this.saveSettingsPopupVisibility = this.settingsInterface.$saveSettingsPopupVisibility = false;
    this.isSignoutClicked();
    this.onInit();
  }

  isSignoutClicked() {
    let param = (this.isSettingClosedInPopup) ? '' : false;
    if (this.menuService.getConnectClickedStatus()) { param = false; }
    if (this.commonService.isSignoutClicked) {
      this.commonService.showSignoutPopup();
    } else {
      // this.commonService.isReportNavigate.next(param);
      (this.menuService.getConnectClickedStatus()) ? this.menuService.onConnectBtnEvent(this.menuService.connectBtnTxt)
        : this.settingsInterface.onRouteChanged(true);
    }
  }

  getSettingsTabEvent(number){
    this.activeTab = number;
    
  }
  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }
  showpopup(type, errorMsg) {
    switch (type) {
      case 'success':
        this.successStatusMessage.statusSuccess(errorMsg);
        break;
     
    }
  }

}
