
import { Component, OnInit, OnDestroy, Output, EventEmitter, ViewChild } from '@angular/core';
import { SettingsService } from '../settings.service';

@Component({
  selector: 'app-reports-settings',
  templateUrl: './reports-settings.component.html',
  styleUrls: ['./reports-settings.component.scss']
})
export class ReportsSettingsComponent implements OnInit, OnDestroy {

  @ViewChild('settingsReportForm') templateForm: any;
  @Output() onChildPrefChanged: EventEmitter<any> = new EventEmitter();

  pref: any = {};
  uoms = [{
    'label': 'English',
    'value': 'english'
  }, {
    'label': 'Metric',
    'value': 'metric'
  }]


  constructor(private settingsService: SettingsService) {
    settingsService.getDataReadyEvent().subscribe(() => {
      this.onSettingsDataAvailable();
    });
  }

  ngOnInit() {
    this.onSettingsDataAvailable();
    this.templateForm.valueChanges.subscribe((value: any) => {
      if (this.templateForm.dirty) {
        this.onChildPrefChanged.emit();
      }
    });
  }

 
  onSettingsDataAvailable(): void {

    const settingsData = this.settingsService.$userPreferences;
    if (settingsData !== undefined) {
      this.pref = settingsData['reports'];
    }
  }


  onToggleClicked(toggleEle): void {
    
    switch (toggleEle.id) {
      case 'autoTimezone':
        this.pref.auto_timezone = !this.pref.auto_timezone;
        break;
    }
    this.onChildPrefChanged.emit();
  }

  ngOnDestroy(): void {
    this.settingsService.getDataReadyEvent().unsubscribe();
  }
}
