

import { Component, OnInit, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import * as _ from 'lodash'
import { SettingsService } from '../settings.service';
import { AppConstants } from '@app/app.constants';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { AuthenticationService } from '@app/Services/authentication.service';
@Component({
    selector: 'app-merge-settings',
    templateUrl: './merge-settings.component.html',
    styleUrls: ['./merge-settings.component.scss']
})
export class MergeSettingsComponent implements OnInit, OnDestroy {

    mergePristineData = {};
    @ViewChild('settingsMergeForm') templateForm: any;
    @Output() onChildPrefChanged: EventEmitter<any> = new EventEmitter();
    // @Output() intervalTimerEmitter: EventEmitter<boolean> = new EventEmitter<boolean>();

    pref: any = {};
    fileFormats = [];
    selectFileFormat: any;
    frequencyWarning: string;
    toggleLabels = { 'onValue': 'On', 'offValue': 'Off' };

     constructor(public settingsService: SettingsService,private http: HttpClient, private loginservice: AuthenticationService) {
         settingsService.getDataReadyEvent().subscribe(() => {
            this.onSettingsDataAvailable();
         });
        this.fileFormats = [{ label: 'CSV', value: 'csv' }, { label: 'OMF', value: 'omf' }];
    }
    
    onToggleChange(toggleState) {
        this.pref.auto_merge = toggleState; 
        this.pref.auto_merge && this.updateSaveSettingBtn()
        this.onChildPrefChanged.emit(); 
    }
    
    ngOnInit() {
        this.templateForm.valueChanges.subscribe((value: any) => {
            setTimeout(() => {
                if (this.templateForm.dirty && !_.isEqual(this.pref, this.mergePristineData)) {
                    this.onChildPrefChanged.emit();
                }
            }, 10);
        });
        this.onSettingsDataAvailable();
    }

    onSettingsDataAvailable(): void {
        const settingsData = this.settingsService.$userPreferences;
        if (settingsData !== undefined) {
            this.mergePristineData = _.cloneDeep(settingsData['dataProcessing'])
            this.pref = settingsData['dataProcessing'];
        }
    }
   
    updateDataExport() {
        this.pref.dataExportEnabled = !this.pref.dataExportEnabled;
    }
  
    updateDataViz() {
        this.pref.dataVizProcessEnabled = !this.pref.dataVizProcessEnabled;
    }
 
    validatePositiveNumber(event): boolean {
        return (!isNaN(event.key))
    }
 
    onKeyUp(event) {
        this.validateRange();
        this.onChildPrefChanged.emit(this.updateSaveSettingBtn());
    }
  
    validateRange() {
        this.frequencyWarning = (Number(this.pref.fileWatcherInterval) < AppConstants.getConstants('MERGE_MIN_FREQUENCY') ||
            Number(this.pref.fileWatcherInterval) > AppConstants.getConstants('MERGE_MAX_FREQUENCY')) ?
            AppConstants.getConstants('MERGE_FREQUENCY_WARNING_1').split(':')[1] : '';
    }
  
    updateSaveSettingBtn() {
        let enableSaveSettingBtn = true;
        enableSaveSettingBtn = (Number(this.pref.fileWatcherInterval) <= AppConstants.getConstants('MERGE_MAX_FREQUENCY') &&
            Number(this.pref.fileWatcherInterval) >= AppConstants.getConstants('MERGE_MIN_FREQUENCY')) ? true : false;
        return enableSaveSettingBtn;
    }
    ngOnDestroy(): void {

    }


 
}
