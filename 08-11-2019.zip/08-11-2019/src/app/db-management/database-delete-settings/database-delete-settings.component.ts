import { DatabaseManagementService } from './../database-management-service';


import { Component, OnInit, ViewEncapsulation, ViewChildren } from '@angular/core';
import { AppConstants } from '@app/constants';

import { Subject } from 'rxjs/Rx'
import 'rxjs/add/operator/debounceTime';
import * as _ from 'lodash';


@Component({
    selector: 'app-database-delete-settings',
    templateUrl: './database-delete-settings.component.html',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./database-delete-settings.component.scss'],

})


export class DatabaseDeleteSettingsComponent implements OnInit {
    @ViewChildren('calendar')
    datePicker: any;

    pref: any = {};

    selectedFileTypes: any = [];
    selectedFileTypesSubject: Subject<any> = new Subject<any>();
    selectedEquipments: any = [];
    selectedAllEquipments: any = [];
    deletedEquipments: any = {}
    isSelectAllChecked: Boolean = false;
    isSelectAllEquipments: Boolean = false;
    isDeleteClicked: Boolean = false;
    fromDateTime: Date;
    toDateTime: Date;
    maxDate: Date;
    fromMaxDate: Date;
    toMaxDate; Date;
    minDate: Date;
    selectedModels: any = [];
    selectedAllModels: any = [];
    displayAlertOnDelete: Boolean = false;
    displaydeleteProgress: Boolean = false;

    cacheEquipments: any[];
    searchResults: any[];
    searchedText: any;
    showIfEquipments: Boolean = false;
    equipmentAvailableInfo: string;
    modelImg: String;


 
    constructor(private databaseManagementService: DatabaseManagementService,
        ) { }
    ngOnInit() {
        this.onChangeDbTab();
        this.listAllFileTypes();
        this.setCurrentDateTime();
        this.debounceOnSelectFileType();
        this.equipmentAvailableInfo = AppConstants.getConstants('SELECT_FILE_TYPE');
        this.modelImg = AppConstants.getConstants('EQUIP_IMG'); // test img url
    }



 
    listAllFileTypes() {
       // this.pref.fileTypes = ["Event","Snapshot","Standard Data Logger","Trend","Cumulative","Histogram","Truck Payload","Loader Payload","Continous Data Logger","Cycle Timer","Productivity"];
        this.databaseManagementService.getFileTypes().subscribe((response) => {
            this.pref.fileTypes = response;
        })

        
    }

    debounceOnSelectFileType() {
        this.selectedFileTypesSubject
            .debounceTime(250)
            .distinctUntilChanged()
            .subscribe((selectedFileTypes) => {
                this.selectedFileTypes = selectedFileTypes;
                if (selectedFileTypes.length) {
                    this.getEquipments();
                } else {
                    this.isFileTypesEmpty();
                    this.selectedEquipments = [];
                    this.selectedModels = [];
                }
            });
    }



    onSelectFileType() {
        (this.pref.fileTypes.length === this.selectedFileTypes.length) ? this.isSelectAllChecked = true : this.isSelectAllChecked = false;
        this.selectedFileTypesSubject.next(this.selectedFileTypes);
    }


    onSelectAllFileTypes(event) {
        if (event) {
            this.selectedFileTypes = this.pref.fileTypes;
            this.getEquipments();
        } else {
            this.selectedFileTypes = [];
            this.selectedEquipments = [];
            this.selectedModels = [];
            this.pref.equipments = {};
            this.isFileTypesEmpty();
        }
    }


    
    onSelectAllEquipments(event) {
        if (event) {
            for (let i = 0; i < this.cacheEquipments.length; i++) {
                this.selectedModels.push(this.cacheEquipments[i].model);
                this.selectedModels = this.selectedModels.slice();
                for (let j = 0; j < this.cacheEquipments[i].associatedSerialNumbers.length; j++) {
                    this.selectedAllEquipments.push(this.cacheEquipments[i].model + '-'
                        + this.cacheEquipments[i].associatedSerialNumbers[j]);
                    this.selectedAllEquipments = this.selectedAllEquipments.slice();
                    this.selectedEquipments.push(this.cacheEquipments[i].model + '-' + this.cacheEquipments[i].associatedSerialNumbers[j]);
                    this.selectedEquipments = this.selectedEquipments.slice();
                }
            }

        } else {
            this.resetEquipmentSelectedData();
        }
    }




    onChangeSerialNumber(event, serial, equipment) {
        if (event) {
            this.selectedAllEquipments.push(serial);
            this.selectedAllEquipments = this.selectedAllEquipments.slice();
        } else {
            this.isSelectAllEquipments = false;
            this.selectedAllEquipments = this.selectedAllEquipments.filter(e => e !== serial);
        }

        for (let i = 0; i < equipment.associatedSerialNumbers.length; i++) {
            if (!(this.selectedAllEquipments.includes(equipment.model + '-' + equipment.associatedSerialNumbers[i]))) {
                this.selectedModels = this.selectedModels.filter(e => e !== equipment.model);
                break;
            }
            if (i === equipment.associatedSerialNumbers.length - 1) {
                this.selectedModels.push(equipment.model);
                this.selectedModels = this.selectedModels.slice();
                if (this.cacheEquipments.length === this.selectedModels.length) {
                    this.isSelectAllEquipments = true;
                }
            }
        }
    }
  
    onChangeModelNumber(event, equipment) {
        if (event) {
            for (let i = 0; i < equipment.associatedSerialNumbers.length; i++) {
                if (!(this.selectedEquipments.includes(equipment.model + '-' + equipment.associatedSerialNumbers[i]))) {
                    this.selectedAllEquipments.push(equipment.model + '-' + equipment.associatedSerialNumbers[i]);
                    this.selectedAllEquipments = this.selectedAllEquipments.slice();
                    this.selectedEquipments.push(equipment.model + '-' + equipment.associatedSerialNumbers[i]);
                    this.selectedEquipments = this.selectedEquipments.slice();
                }
            }
            this.selectedAllModels.push(equipment.model);
            this.selectedAllModels = this.selectedAllModels.slice();
        } else {
            this.isSelectAllEquipments = false;
            this.selectedAllModels = this.selectedAllModels.filter(e => e !== equipment.model);
            for (let j = 0; j < equipment.associatedSerialNumbers.length; j++) {
                if (this.selectedEquipments.includes(equipment.model + '-' + equipment.associatedSerialNumbers[j])) {
                    this.selectedAllEquipments =
                        this.selectedAllEquipments.filter(e => e !== equipment.model + '-' + equipment.associatedSerialNumbers[j]);
                    this.selectedEquipments = this.selectedEquipments.filter(e =>
                        e !== equipment.model + '-' + equipment.associatedSerialNumbers[j]);
                }
            }
        }
        this.isSelectAllEquipments = (this.cacheEquipments.length === this.selectedModels.length) ? true : false;
    }

 
    onSearchEquipments(event) {
        const query = event.query;
        if (this.pref.equipments) {
            this.searchResults = this.filterEquipments(query, this.pref.equipments);
        }

    }

 
    filterEquipments(query, cacheEquipments: any[]): Array<object> {
        const filtered: any[] = [];
        for (let i = 0; i < cacheEquipments.length; i++) {
            const modelList = cacheEquipments[i];
            if (modelList.model.toLowerCase().indexOf(query.toLowerCase()) === 0) {
                filtered.push(modelList.model);
            } else {
                for (let j = 0; j < modelList.associatedSerialNumbers.length; j++) {
                    if (modelList.associatedSerialNumbers[j].toLowerCase().indexOf(query.toLowerCase()) === 0) {
                        if (filtered.indexOf(modelList.associatedSerialNumbers[j]) === -1) {
                            filtered.push(modelList.associatedSerialNumbers[j]);
                        }
                    }
                }
            }
        }
        return filtered;
    }

    getFilteredEquipmentlist(value) {
        this.cacheEquipments = _.filter(this.pref.equipments, (item) => {
            if (item.model === value) {
                return true;
            }
            return _.find(item.associatedSerialNumbers, (serial) => {
                if (serial === value) {
                    return true;
                }
            })
        });
        this.resetEquipmentSelectedData();
    }

    onClearGetEquipment() {
        this.cacheEquipments = this.pref.equipments;
        this.resetEquipmentSelectedData();
    }


    onSelectFromDate(): void {
        this.setMinDate();
        this.onChangedate();
    }


    onSelectToDate(): void {
        this.setMaxDate();
        this.onChangedate();
    }

    onChangedate() {
        this.datePicker.overlayVisible = false;
        if (this.selectedFileTypes.length) {
            this.selectedEquipments = [];
            this.getEquipments();
        }
    }



    setCurrentDateTime(): void {
        this.fromDateTime = new Date();
        this.toDateTime = new Date();
        this.fromMaxDate = new Date();
        this.toMaxDate = new Date();
        this.fromDateTime.setDate(this.fromDateTime.getDate() - 1);
        this.toDateTime.setDate(this.toDateTime.getDate());
        this.fromMaxDate.setDate(this.fromMaxDate.getDate());
        this.toMaxDate.setDate(this.toMaxDate.getDate());
        this.setMinDate();
    }

    setMinDate(): void {
        this.minDate = new Date();
        const setToMinDate = new Date(this.fromDateTime);
        const numDate = this.getNumericDate(setToMinDate);
        this.minDate.setFullYear(numDate.yy, numDate.mm, numDate.dd);
    }

    setMaxDate(): void {
        this.fromMaxDate = new Date();
        const setMaxDate = new Date(this.toDateTime);
        const numDate = this.getNumericDate(setMaxDate);
        this.fromMaxDate.setFullYear(numDate.yy, numDate.mm, numDate.dd);
    }

    getNumericDate(Obj: Date) {
        return {
            yy: Obj.getFullYear(),
            mm: Obj.getMonth(),
            dd: Obj.getDate()
        };
    }


  
    isFileTypesEmpty() {
        this.cacheEquipments = [];
        this.showIfEquipments = false;
        this.equipmentAvailableInfo = AppConstants.getConstants('SELECT_FILE_TYPE');
    }


    equipmentsParam() {
        return {
            startTime: this.calcUTCFormat(this.fromDateTime),
            endTime: this.calcUTCFormat(this.toDateTime),
            selectedFileTypes: this.selectedFileTypes
        }
    }

    calcUTCFormat(selectedDate) {
        const currentDate = new Date(selectedDate);
        const YYYY = currentDate.getFullYear();
        const MM = this.leadingZero(currentDate.getMonth() + 1);
        const DD = this.leadingZero(currentDate.getDate());
        const HH = this.leadingZero(currentDate.getHours());
        const MIN = this.leadingZero(currentDate.getMinutes());
        const formatedDate = `${YYYY}-${MM}-${DD}T${HH}:${MIN}:00.000Z`
        return formatedDate
    }

    leadingZero(value) {
        return (value < 10) ? `0${value}` : value
    }



    getEquipments(): void {
        // const paramObj = this.equipmentsParam();
        // this.databaseManagementService.getEquipmentLists(paramObj).subscribe((response) => {
        //     this.handleGetEquipmentsListsSuccess(response);
        // }, (err) => {
        //     console.log(err);
        //     this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'), err.status + ' - ' + err.statusText);
        //     if (err.status === 404) {
        //         this.equipmentAvailableInfo = AppConstants.getConstants('TRY_AGAIN');
        //     }
        // })

    }
    handleGetEquipmentsListsSuccess(response) {
        this.pref.equipments = response;
        this.cacheEquipments = (this.pref.equipments !== null) ? this.pref.equipments : [];
        const isCacheEquipments = (this.cacheEquipments.length > 0) ? true : false;
        const isSelectedFileTypes = (this.selectedFileTypes.length > 0) ? true : false
        this.showIfEquipments = isCacheEquipments;
        this.equipmentAvailableInfo = (!isCacheEquipments && !isSelectedFileTypes) ?
            AppConstants.getConstants('SELECT_FILE_TYPE') : AppConstants.getConstants('NO_EQUIPMENTS_AVAILABLE')
        this.resetEquipmentSelectedData();
        this.searchedText = null;
    }
    showDeleteAlert() {
        this.displayAlertOnDelete = true;
    }

    cancelDelete() {
        this.displayAlertOnDelete = false;
    }

    confirmDelete() {
        this.displayAlertOnDelete = false;
        this.displaydeleteProgress = true;
        this.deleteEquipments();
    }
  
    deletedSerailListObj() {
        const deletedObj: any = {
            startTime: this.calcUTCFormat(this.fromDateTime),
            endTime: this.calcUTCFormat(this.toDateTime)
        }
        deletedObj.selectedFileTypes = this.selectedFileTypes;
        const checkSelectAllEquipment = (this.pref.equipments.length === this.selectedModels.length) ? true : false;
        if (!checkSelectAllEquipment) {
            const items = {};
            items['modelStructureDTOList'] = [];
            let j = 0;
            for (let i = 0; i < this.selectedEquipments.length; i++) {
                if (items['modelStructureDTOList'].length > 0) {
                    for (let k = 0; k < items['modelStructureDTOList'].length; k++) {
                        if (items['modelStructureDTOList'][k]['model'] === this.selectedEquipments[i].split('-')[0]) {
                            if (items['modelStructureDTOList'][j]['associatedSerialNumbers'].indexOf(
                                this.selectedEquipments[i].split('-')[1]) === -1) {
                                items['modelStructureDTOList'][j]['associatedSerialNumbers'].push(this.selectedEquipments[i].split('-')[1]);
                            }
                        } else {
                            if (k === items['modelStructureDTOList'].length - 1) {
                                j++;
                                items['modelStructureDTOList'][j] = {
                                    model: this.selectedEquipments[i].split('-')[0],
                                    associatedSerialNumbers: [this.selectedEquipments[i].split('-')[1]]
                                }
                            }
                        }
                    }
                }
                if (i === 0) {
                    items['modelStructureDTOList'][i] = {
                        model: this.selectedEquipments[i].split('-')[0],
                        associatedSerialNumbers: [this.selectedEquipments[i].split('-')[1]]
                    }
                }
            }

            deletedObj.modelStructureDTOList = items['modelStructureDTOList'];
            return deletedObj;
        }
        this.resetEquipmentSelectedData();
    }


    deleteEquipments() {
        // const checkSelectAllEquipment = (this.pref.equipments.length === this.selectedModels.length) ? true : false;
        // if (!checkSelectAllEquipment) {
        //     this.deletedEquipments = this.deletedSerailListObj();
        //     this.databaseManagementService.deleteEquipmentLists(this.deletedEquipments).subscribe((response) => {
        //         this.onSuccessDeleteEquipment(response);
        //     }, (err) => {
        //         console.log(err);
        //         this.displaydeleteProgress = false;
        //     })
        // } else {
        //     this.deleteAllEquipments();
        // }

    }



    deleteAllEquipments() {
        // const paramObj = this.equipmentsParam();
        // this.databaseManagementService.deleteAllSelectedEquipments(paramObj).subscribe((response) => {
        //     this.onSuccessDeleteEquipment(response);
        // }, (err) => {
        //     console.log(err);
        //     this.displaydeleteProgress = false;
        // })
    }


    onSuccessDeleteEquipment(response) {
        // const isSuccess: string = (response) ? AppConstants.getConstants('GROWL_SUCCESS') : AppConstants.getConstants('GROWL_ERROR');
        // this.modelInterruptService.displayToast(isSuccess, AppConstants.getConstants('DELETE_SUCCESS'));
        // this.isDeleteClicked = false;
        // this.displaydeleteProgress = false;
        // this.getEquipments();
    }

    resetDeleteData() {
        this.selectedFileTypes = [];
        this.pref.equipments = {};
        this.isSelectAllChecked = false;
        this.isFileTypesEmpty();
        this.setCurrentDateTime();
        this.resetEquipmentSelectedData();
    }

    resetEquipmentSelectedData() {
        this.selectedEquipments = [];
        this.selectedModels = [];
        this.isSelectAllEquipments = false;
        this.selectedAllEquipments = [];
    }



    onChangeDbTab() {
        this.databaseManagementService.dbTabEvents$.forEach(event => {
            if (event.index === 1) {
                this.resetDeleteData();
            }
        });
        // this.settingsInterface.settingsTabEvents$.forEach(event => {
        //     if (event) {
        //         this.resetDeleteData();
        //     }
        // });
    }


}

