
import { environment } from '@env/environment';
import { Observable, Subject } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiConstants } from '@app/api.constants';



@Injectable()
export class DatabaseManagementService {
  private manageDBTabEvent: Subject<any> = new Subject<any>();

  constructor(private http: HttpClient) { }

  getFileTypes() {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('getFileTypeList'));
  }

 
  getEquipmentLists(getEquipmentsObj) {
    // const getEquipmentsUrl = environment.baseUrl + ApiConstants.getAPI('getFileTypeEquipments');
    // return this.http.post(getEquipmentsUrl, getEquipmentsObj);
  }

  
  deleteEquipmentLists(deleteEquipmentsObj) {
    // const deleteEquipmentsUrl = environment.baseUrl + ApiConstants.getAPI('deleteFileTypeEquipments');
    // return this.http.post(deleteEquipmentsUrl, deleteEquipmentsObj);
  }


  deleteAllSelectedEquipments(deleteAllEquipmentsObj) {
    // const deleteEquipmentsUrl = environment.baseUrl + ApiConstants.getAPI('deleteAllSelectedFileTypeEquipments');
    // return this.http.post(deleteEquipmentsUrl, deleteAllEquipmentsObj);
  }

 
  getDefaultFilePath() {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('defaultDBBackupPath'));
  }

 
  dbBackupPreValidation() {
    //return this.http.post(environment.baseUrl + ApiConstants.getAPI('dbBackupPreValidation'), {});
  }


  calcApproximateTimeForBackup() {
    //return this.http.post(environment.baseUrl + ApiConstants.getAPI('calculateApproximateValueForBackup'), {});
  }


  backUpData() {
    //return this.http.get(environment.baseUrl + ApiConstants.getAPI('getDbBackup'));
  }


  getRestoreFiles(filepathObj) {
    const getRestoreFilesUrl = environment.baseUrl + ApiConstants.getAPI('loadRestoreFiles');
    return this.http.post(getRestoreFilesUrl, filepathObj);
  }


  calcApproximateTimeForRestore(filepathObj) {
    // const calcApproxRestoreTimeUrl = environment.baseUrl + ApiConstants.getAPI('calculateApproximateValueForRestore');
    // return this.http.post(calcApproxRestoreTimeUrl, filepathObj);
  }

  dbRestorePreValidation(filepathObj) {
    // const dbRestorePreValidateUrl = environment.baseUrl + ApiConstants.getAPI('dbRestorePreValidation');
    // return this.http.post(dbRestorePreValidateUrl, filepathObj);
  }


  updateRestoreFiles(filepathObj) {
    // const getdbRestoreUrl = environment.baseUrl + ApiConstants.getAPI('dbRestore');
    // return this.http.post(getdbRestoreUrl, filepathObj);
  }


  setDbTabEvent(event) {
    this.manageDBTabEvent.next(event);
  }
  get dbTabEvents$() {
    return this.manageDBTabEvent.asObservable();
  }

}


