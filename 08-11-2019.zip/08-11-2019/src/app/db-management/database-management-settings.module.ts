import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BackupRestoreSettingsComponent } from './backup-restore-settings/backup-restore-settings.component';
import { DatabaseDeleteSettingsComponent } from './database-delete-settings/database-delete-settings.component';
import { DatabaseManagementSettingsComponent } from './database-management-settings.component';
import { DatabaseManagementService } from './database-management-service';
import { RouterModule } from '@angular/router';
import { TabViewModule, RadioButtonModule, DropdownModule, SelectButtonModule, CheckboxModule, OverlayPanelModule, CalendarModule, AccordionModule, DialogModule, ProgressBarModule } from 'primeng/primeng';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot([]),HttpClientModule,
    HttpModule,
    TabViewModule, RadioButtonModule, DropdownModule, SelectButtonModule, CheckboxModule, OverlayPanelModule, CalendarModule, AccordionModule, DialogModule, ProgressBarModule
  ],
  declarations: [  BackupRestoreSettingsComponent,DatabaseManagementSettingsComponent,
    DatabaseDeleteSettingsComponent],
    exports: [DatabaseManagementSettingsComponent],
    schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
    providers:[DatabaseManagementService]  
})
export class DatabaseManagementSettingsModule { }
