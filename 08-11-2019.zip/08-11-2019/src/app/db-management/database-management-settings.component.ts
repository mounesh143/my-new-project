import { DatabaseManagementService } from './database-management-service';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';



@Component({
  selector: 'app-database-management-settings',
  templateUrl: './database-management-settings.component.html',
  styleUrls: ['./database-management-settings.component.scss']
})
export class DatabaseManagementSettingsComponent implements OnInit {
  @Output() onChildPrefChanged: EventEmitter<any> = new EventEmitter();

  constructor(private databaseManagementService: DatabaseManagementService) { }

  ngOnInit() { }

  onDbTabChanged(event) {
    this.databaseManagementService.setDbTabEvent(event)
  }


}
