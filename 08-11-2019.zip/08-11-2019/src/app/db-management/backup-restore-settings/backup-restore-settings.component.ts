



import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';

import { Observable } from 'rxjs/Rx';
import * as _ from 'lodash';
import { DatabaseManagementService } from '../database-management-service';
import { StompMsgService } from '../../core/stomp.service';
import { SuccessStatusMessage } from '@app/success.service';
import { CommonService } from '@app/common.service';



@Component({
    selector: 'app-backup-restore-settings',
    templateUrl: './backup-restore-settings.component.html',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./backup-restore-settings.component.scss']
})
export class BackupRestoreSettingsComponent implements OnInit, OnDestroy {
    pref: any = {};

    displayConfirmBackupDialog = false;
    displayProgressbarPopup = false;
    displayRestoreProgressbar = false;
    displayConfirmRestoreDialog = false;
    overallProgress = 0;
    backupDbSubscription: any;
    restoreDbSubscription: any;
    selectedDbFile: any;
    defaultPath: any;
    restorePath: any;
    restoreFileList: any = [];
    selectedPath: any;
    fileListsSubscription: any;
    timerSubscription: any;
    refreshedData: any = [];
    isFileOrdered: Boolean = false;
    approxBackupTime: any;
    approxRestoreTime: any;


    constructor(//private commonService: CommonService,
        private databaseManagementService: DatabaseManagementService, private stomp: StompMsgService,
        private successStatusMessage: SuccessStatusMessage,commonsService:CommonService
        ) { }

    ngOnInit() {
        this.getDefaultPath();
        this.onChangeDbTab();
        this.restorePath = "C:\Users\Public\Caterpillar\NGSITESOLUTIONS\backupdb";
    }

    confirmDialog() {
        this.displayConfirmBackupDialog = true;
    }

 
    cancelBackup() {
        this.displayConfirmBackupDialog = false;
    }

    confirmBackup() {
        this.displayConfirmBackupDialog = false;
        this.backupPreValidation();
    }

  
    initStompChannels(action): void {
        this.stomp.connect().then(() => {
            if (action === 'backup') {
                this.subscribeToBackupDbProgress();
            } else {
                this.subscribeToRestoreDbProgress();
            }
        })
    }


    getDefaultPath() {
        this.databaseManagementService.getDefaultFilePath().subscribe((response) => {
            this.defaultPath = response['filePath'];
            this.restorePath = this.defaultPath;
            this.listRestoreFiles();
        }, (err) => {
            this.showpopup('success', 'Internal Server Error')
        });
    }

    showpopup(type, errorMsg) {
        switch (type) {
          case 'success':
            this.successStatusMessage.statusSuccess(errorMsg);
            break;
         
        }
      }


    backupPreValidation() {
        // this.databaseManagementService.dbBackupPreValidation().subscribe((response) => {
        //     this.backupPreValidationSuccess(response);
        // }, (err) => {
        //     console.log(err);
        //     this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'), AppConstants.getConstants('BACKUP_ERROR'));

        // });
    }

    /* istanbul ignore next */
    backupPreValidationSuccess(response) {
        // if (response.success) {
        //     this.backupDatabase();
        //     this.backupTimeCalculation();
        // } else {
        //     this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'), response.result);
        // }
    }


    backupTimeCalculation() {
        // this.approxBackupTime = 1;
        // this.databaseManagementService.calcApproximateTimeForBackup().subscribe((response) => {
        //     this.calcApproximateTimeForBackupSuccess(response);
        // });
    }

    calcApproximateTimeForBackupSuccess(response) {
        // if (response.result) {
        //     this.approxBackupTime = (response.result === 0) ? 1 : response.result;
        // }
    }
   
    backupDatabase() {
        // (this.timerSubscription) ? this.timerSubscription.unsubscribe() : console.log('')
        // this.initStompChannels('backup');
        // this.displayProgressbarPopup = true;
        // this.overallProgress = 0;
        // this.databaseManagementService.backUpData().subscribe((response) => {
        //     this.backupDataSuccess(response);
        // }, (err) => {
        //     console.log(err);
        //     this.displayProgressbarPopup = false;
        //     this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'), AppConstants.getConstants('BACKUP_ERROR'));
        // });

    }

    backupDataSuccess(response) {
        // const isSuccess: string = (response.status === 0) ?
        //     AppConstants.getConstants('GROWL_SUCCESS') : AppConstants.getConstants('GROWL_ERROR');
        // if (response) {
        //     this.displayProgressbarPopup = false;
        //     this.listRestoreFiles();
        // }
        // if (response.status === 0) {
        //     this.modelInterruptService.displayToast(isSuccess, AppConstants.getConstants('BACKUP_SUCCESS'));
        // }
    }


    subscribeToBackupDbProgress(): void {
        // this.backupDbSubscription = this.stomp.getStomp().subscribe(ApiConstants.getAPI('backupChannel'), (overallProgressObj) => {
        //     const progressPercentage = Math.round(overallProgressObj.backupPercentage);
        //     this.overallProgress = (progressPercentage > 100) ? 100 : progressPercentage;
        // });
    }



    onChangeDbTab() {
        // this.databaseManagementService.dbTabEvents$.forEach(event => {
        //     if (event.index === 0) {
        //         this.listRestoreFiles();
        //     }
        // });
        // this.settingsInterface.settingsTabEvents$.forEach(event => {
        //     if (event) {
        //         this.getDefaultPath();
        //         this.listRestoreFiles();
        //     }
        // });
    }


 
    listRestoreFiles() {
       
       
        this.databaseManagementService.getRestoreFiles(this.restorePath).subscribe((response) => {
            this.getRestoreFilesSuccess(response);
        }, (err) => {
            console.log(err);
        });
    }

    getRestoreFilesSuccess(response) {
        this.restoreFileList = response.dbRestoreFilesDTOList;
        console.log(this.restoreFileList);
        if (this.restoreFileList) {
            this.selectedDbFile = this.restoreFileList[0]['filePath'];
        }
        this.refreshRestoreFiles();
    }

    /**
       * @description Used to watch and refresh file list in the selected path
       * @param
       * @memberof BackupRestoreSettingsComponent
       */
    refreshRestoreFiles(): void {
        // this.fileListsSubscription = this.databaseManagementService.getRestoreFiles(this.restorePath).subscribe(response => {
        //     this.refreshRestoreFilesSuccess(response);
        // });
    }

    refreshRestoreFilesSuccess(response) {
        this.refreshedData = response.dbRestoreFilesDTOList;
        this.subscribeToTimer();
        this.rebuildRestoreFiles();
    }

    subscribeToTimer(): void {
        // this.timerSubscription = Observable.timer(AppConstants.getConstants('RESTORE_LIST_TIMER')).first().subscribe(() => {
        //     if (this.refreshedData.length !== 0) {
        //         this.refreshRestoreFiles();
        //     }
        // });
    }


    rebuildRestoreFiles() {
        const isEqualList: Boolean = (this.restoreFileList.length === this.refreshedData.length) ? true : false;
        if (!isEqualList) {
            this.restoreFileList = this.refreshedData;
            this.selectedDbFile = this.restoreFileList[0]['filePath'];
        }
    }


    sortRestoreFiles() {
        if (this.isFileOrdered) {
            this.restoreFileList = _.orderBy(this.restoreFileList, ['lastModifiedDate'], ['desc']);
        } else {
            this.restoreFileList = _.orderBy(this.restoreFileList, ['lastModifiedDate'], ['asc']);
        }
        this.selectedDbFile = this.restoreFileList[0]['filePath'];
        this.isFileOrdered = !this.isFileOrdered;
    }

 
    changeFilePath() {
        const selectedFile: any = (<HTMLInputElement>document.getElementById('path-file-input')).files[0];
        const selectedFilePath = selectedFile.path;
        this.restorePath = selectedFilePath;
        this.listRestoreFiles();
    }


    restoreDb() {
        this.displayConfirmRestoreDialog = true;
    }

 
    cancelRestore() {
        this.displayConfirmRestoreDialog = false;
    }

    confirmRestore() {
        this.displayConfirmRestoreDialog = false;
        this.restorePreValidation();
    }

    subscribeToRestoreDbProgress(): void {
        // this.restoreDbSubscription = this.stomp.getStomp().subscribe(ApiConstants.getAPI('restoreChannel'), (overallProgressObj) => {
        //     const progressPercentage = Math.round(overallProgressObj.restorePercentage);
        //     this.overallProgress = (progressPercentage > 100) ? 100 : progressPercentage;
        // });
    }

    restorePreValidation() {
        // this.databaseManagementService.dbRestorePreValidation(this.selectedDbFile).subscribe((response) => {
        //     this.handlerestorePreValidationSuccess(response);
        // }, (err) => {
        //     console.log(err);
        //     this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'), AppConstants.getConstants('RESTORE_FAIL'));
        // });
    }

    /* istanbul ignore next */
    handlerestorePreValidationSuccess(response) {
        // if (response.success) {
        //     this.restoreFile();
        //     this.restoreTimeCalculation();
        // } else {
        //     this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'), response.result);
        // }
    }
  
    restoreTimeCalculation() {
        // this.approxRestoreTime = 1;
        // this.databaseManagementService.calcApproximateTimeForRestore(this.selectedDbFile).subscribe((response) => {
        //     if (response.result) {
        //         this.approxRestoreTime = (response.result === 0) ? 1 : response.result;
        //     }
        // });
    }


    restoreFile() {
        // this.initStompChannels('restore');
        // this.displayRestoreProgressbar = true;
        // this.overallProgress = 0;
        // this.databaseManagementService.updateRestoreFiles(this.selectedDbFile).subscribe((response) => {
        //     this.updateRestoreFilesSuccess(response);
        // }, (err) => {
        //     console.log(err);
        //     this.displayRestoreProgressbar = false;
        //     this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'), AppConstants.getConstants('RESTORE_FAIL'));
        // });
    }

    /* istanbul ignore next */
    updateRestoreFilesSuccess(response) {
        // if (response) {
        //     this.displayRestoreProgressbar = false;
        // }
        // if (response.status === 0) {
        //     this.modelInterruptService.createAlert(AppConstants.ALERT_IDS['DB_RESTORED'],
        //         AppConstants.getConstants('DB_RESTORED')).show().subscribe((alertResponse) => {
        //         })
        // } else {
        //     this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'), AppConstants.getConstants('RESTORE_FAIL'));
        // }
    }

   

    ngOnDestroy() {

    }
}
