import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpModule } from '@angular/http'
import { appReducers } from './reducers/app.reducers';
import { AppComponent } from './app.component';
import { MergeModule } from './merge/merge.module';
import { RouterModule} from '@angular/router'
import {FormsModule, ReactiveFormsModule} from '@angular/forms'

//import { MergeComponent } from './merge/merge.component';
import {
  StompMsgService, CommonService,MenuService,ModelInterruptService, StomMsgModule,
} from 'app/core';
import { StoreModule } from '@ngrx/store';
import { StompService } from 'ng2-stomp-service';
import { HeaderComponent } from './header/header.component';
import { AuthenticationService } from './Services/authentication.service';
import { AuthGuard } from './Services/authGaurd.service';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app.routing.module';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TabViewModule,RadioButtonModule, DropdownModule, SelectButtonModule, CheckboxModule, OverlayPanelModule, CalendarModule, AccordionModule, DialogModule, ProgressBarModule } from 'primeng/primeng';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { SettingsService } from './tools-setting/settings.service';
import { AuthInterceptorService } from './Services/auth-interceptor.service';
import { DatabaseManagementSettingsModule } from './db-management/database-management-settings.module';
import { ToolsSettingModule } from './tools-setting/tools-setting.module';
import { ClickOutsideDirective } from './Directive/click-outside.directive';
import { InterruptModule } from '@app/modelInterrupt.module';
import { SuccessStatusMessage } from '@app/success.service';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
import { PreferenceService } from './tools-setting/preference.service';
import { MergeService } from './merge/merge.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    HomeComponent,
    DashboardComponent,
    ClickOutsideDirective
  ],
  imports: [
    BrowserAnimationsModule,
    InterruptModule,
    DatabaseManagementSettingsModule,
    ToolsSettingModule,
    ProgressBarModule,
    SelectButtonModule,
    StomMsgModule,
    DialogModule,
    TabViewModule,
    CheckboxModule,
    OverlayPanelModule,
    CalendarModule,
    CheckboxModule,
    AccordionModule,
    BrowserModule,FormsModule,RouterModule,HttpModule,HttpClientModule,ReactiveFormsModule,DropdownModule,
    MergeModule,StoreModule.forRoot(appReducers),AppRoutingModule,TabViewModule,CommonModule,RadioButtonModule
    //ApiConstants,AppConstants,
    
  ],
  providers: [CommonService,MenuService,ModelInterruptService,StompMsgService,SuccessStatusMessage,
    StompService,AuthenticationService,AuthGuard,PreferenceService,
    {provide: APP_BASE_HREF, useValue : '/' },
    { provide:HTTP_INTERCEPTORS,
     useClass : AuthInterceptorService,
    multi:true }],
  schemas: [NO_ERRORS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
