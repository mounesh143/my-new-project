import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HomeComponent } from './home.component';
import { HeaderComponent } from '@app/header/header.component';
import { RouterModule } from '@angular/router';
import { AuthenticationService } from '@app/Services/authentication.service';
import { HttpClientModule } from '@angular/common/http';
import { SettingsService } from '@app/tools-setting/settings.service';
describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeComponent,HeaderComponent ],
      imports : [RouterModule,RouterTestingModule,HttpClientModule],
      providers:[AuthenticationService,SettingsService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
