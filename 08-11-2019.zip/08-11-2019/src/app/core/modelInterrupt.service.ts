import { DomSanitizer } from '@angular/platform-browser';
// import { ElectronService } from 'ngx-electron';
import { AppConstants } from '../constants'
import { Alert } from '../Alert'
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { Message } from 'primeng/primeng';
import { environment } from '../../environments/environment'

@Injectable()
export class ModelInterruptService {
  alerts = [];
  toast: Message[] = [];

  constructor( private sanitizer: DomSanitizer) { }
 
  createAlert(id: string, message: string, title: string = AppConstants.getConstants('alert'),
    btnText: string = AppConstants.getConstants('OK')): Alert {
    const sanitizedMsg = this.sanitizer.bypassSecurityTrustHtml(message);
    const activeAlert = this.alerts.filter((item) => item.id === id);
    const activeAlertIndex = this.alerts.indexOf(activeAlert[0]);
    const alert: Alert = (activeAlertIndex === -1) ? new Alert(id, sanitizedMsg, title, btnText) :
      this.getDuplicateAlert(activeAlertIndex, sanitizedMsg);
    this.alerts.push(alert);
    return this.alerts[this.alerts.length - 1];
  }

  /**
   * @description Used to get duplicated alert
   * @author Vigneswar Chelliah
   * @param {*} duplicateIndex
   * @param {*} msg
   * @returns {Alert}
   * @memberof ModelInterruptService
   */
  getDuplicateAlert(duplicateIndex, msg): Alert {
    const duplicateAlert: Alert = _.cloneDeep(this.alerts.splice(duplicateIndex, 1)[0]);
    duplicateAlert.updateMessage(msg);
    return duplicateAlert;
  }

  /**
   * @description Used to remove object from array
   * @author Vigneswar Chelliah
   * @param {any} obj
   * @memberof ModelInterruptService
   */
  removeAlert(obj, eleClicked) {
    const object = { 'id': obj.id, 'eleClicked': eleClicked };
    obj.closeListener.next(object);
    const activeAlert = this.alerts.filter((item) => item.id === obj.id);
    const activeAlertIndex = (activeAlert.length) ? this.alerts.indexOf(activeAlert[0]) : activeAlert.length;
    this.alerts.splice(activeAlertIndex, 1);
  }





  reloadExistingWindow(existingWindow) {
    existingWindow.reload();
    existingWindow.show();
  }

 
  // closeExistingAndCreateNew(existingWindow, filePath) {
  //   existingWindow.close();
  //   this.createNewWindow(filePath);
  // }


  /* istanbul ignore next */
  createNewWindow(filePath) {
    // const bWindow = new this.electronService.remote.BrowserWindow({
    //   minHeight: 600,
    //   minWidth: 800,
    //   frame: true,
    //   title: environment.applicationName
    // });
  
  }
  closeExistingAndCreateNew(existingWindow, filePath) {
    existingWindow.close();
    this.createNewWindow(filePath);
  }
  openWindow(path, id?) {
    const filePath = path.replace(/\\/g, '/');
    const isHttp = (path.indexOf('http') > -1);
   
    const searchString = (id) ? id : filePath;
    this.createNewWindow(filePath);
    
 
  }

  displayToast(toastSeverity, toastContent, isClearExistingToasts: boolean = false) {
    this.toast = isClearExistingToasts ? [] : this.toast;
    const object = { severity: toastSeverity, detail: toastContent };
    this.toast.push(object);
    this.toast = JSON.parse(JSON.stringify(this.toast));
  }


 
  clearToast() {
    this.toast = [];
  }
}
