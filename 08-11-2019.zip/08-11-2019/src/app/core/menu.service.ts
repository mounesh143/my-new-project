import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Injectable, Output, EventEmitter } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { ApiConstants } from '../constants';
import { environment } from '../../environments/environment';

@Injectable()
export class MenuService {
  menuItems = [];

  /* public variabled to set Connect button status and test */

  public connecBtnClicked = false;

  public connectBtnTxt = '';

  @Output() private connectBtnEvent: EventEmitter<string> = new EventEmitter();
  @Output() private connectResEvent: EventEmitter<string> = new EventEmitter();
  @Output() private verifyResEvent: EventEmitter<string> = new EventEmitter();

  disconnect: Subject<any> = new Subject<any>();

  constructor(private http: HttpClient) { }
  /**
   * @description Used to get event of connectBtnEvent
   * @author Vigneswar Chelliah
   * @returns {EventEmitter<string>}
   * @memberof MenuService
   */
  getConnectBtnEvent(): EventEmitter<string> {
    return this.connectBtnEvent;
  }
  /**
   * @description Used to emit connectBtn Event
   * @author Vigneswar Chelliah
   * @param {any} btnTxt
   * @memberof MenuService
   */
  onConnectBtnEvent(btnTxt): void {
    this.connecBtnClicked = false;
    this.connectBtnEvent.emit(btnTxt);
  }
  /**
   * @description Used to get event of connectResEvent
   * @author Vigneswar Chelliah
   * @returns {EventEmitter<string>}
   * @memberof MenuService
   */
  getConnectResEvent(): EventEmitter<string> {
    return this.connectResEvent;
  }
  /**
   * @description Used to emit connectResEvent
   * @author Vigneswar Chelliah
   * @param {any} status
   * @memberof MenuService
   */
  onConnectResEvent(status): void {
    this.connectResEvent.emit(status);
  }
  /**
   * @description Used to get event of verifyResEvent
   * @author Vigneswar Chelliah
   * @returns {EventEmitter<any>}
   * @memberof MenuService
   */
  getVerifyResEvent(): EventEmitter<any> {
    return this.verifyResEvent;
  }
  /**
   * @description Used to emit verifyResEvent
   * @author Vigneswar Chelliah
   * @param {any} isVerified
   * @memberof MenuService
   */
  onVerifyResEvent(isVerified): void {
    this.verifyResEvent.emit(isVerified);
  }

  /**
   *  @description to set connect is clicked without saving the settings changes
   * @author Davakumar
   * @param {String} button text
   * @memberof MenuComponent
   */
  setConnectClickedStatus(status, btnTxt) {
    this.connecBtnClicked = status;
    this.connectBtnTxt = btnTxt;
  }

  /**
   *  @description to set connect is clicked without saving the settings changes
   * @author Davakumar
   * @param {String} button text
   * @memberof MenuComponent
   */
  getConnectClickedStatus() {
    return this.connecBtnClicked;
  }

  /**
   * User story [378] 08/12/2017
   * @description Used to get menu items menu_items.json from assets/data/
   * @author Vigneswar Chelliah
   * @returns {*}
   * @memberof MenuService
   */
  public getMenuItems(): Observable<any> {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('menuItems'));
    // return this.http.get('assets/data/menu_items.json');
  }
}
