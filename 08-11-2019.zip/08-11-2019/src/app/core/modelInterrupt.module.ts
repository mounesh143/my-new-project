import { ModelInterruptService } from './modelInterrupt.service';
import { GrowlModule, DialogModule } from 'primeng/primeng';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelInterruptComponent } from './modelInterrupt.component';


@NgModule({
  imports: [
    CommonModule, DialogModule, GrowlModule
  ],
  providers: [ModelInterruptService],
  declarations: [ModelInterruptComponent],
  exports: [ModelInterruptComponent]
})
export class InterruptModule { }
