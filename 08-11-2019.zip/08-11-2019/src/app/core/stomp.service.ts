import { StompService } from 'ng2-stomp-service';

import { environment } from '@env/environment';
import { ApiConstants } from '@app/constants';
import {forwardRef, Injectable, NgModule} from '@angular/core';
@NgModule({providers: [forwardRef(() => StompMsgService)]})
export class StomMsgModule {
}
@Injectable()
export class StompMsgService {

  subscriptions = {
    'init': false,
    '/topic/downloadChannel': false,
    '/topic/connectChannel': false,
    '/topic/connectNotificationsChannel': false,
    '/topic/rtpChannel': false,
    '/topic/fileStatusChannel': false,
    '/topic/mergeChannel': false,
    '/topic/autoMergeChannel': false,
    '/topic/genericChannel ': false,
    '/topic/backupChannel': false,
    '/topic/restoreChannel': false
  }

  getChannelKey(channelName, propertyName) {
    const obj = {
      '/topic/genericChannel': {
        'isUpdateAvailable': 'isUpdateAvailable',
        'isAppStarted': 'isAppStarted',
        'LicenseExpired': 'LicenseExpired',
        'loggedInNDaysBefore': 'loggedInNDaysBefore',
        'lastSuccessfulSync|120': 'lastSuccessfulSync|120',
        'lastSuccessfulSync|72': 'lastSuccessfulSync|72',
        'lastSuccessfulSync|96': 'lastSuccessfulSync|96',
        'vims-reconnect': 'vims-reconnect'
      }
    }
    return obj[channelName][propertyName];
  }

  constructor(private stomp: StompService) {
   
  }
  ngOnit(){
    this.stomp.configure({
      host: environment.stompUrl + ApiConstants.getAPI('webSocketHandler'),
      debug: true,
      queue: this.subscriptions
    });
  }
 
  getStomp(): StompService {
    return this.stomp;
  }

  connect(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.stomp.startConnect().then(() => {
        
        this.stomp.done('init');
        resolve();
      });
    });
  }

  disconnect(): void {
    this.stomp.disconnect();
  }
 
  getCurrentStatus(): string {
    return this.stomp.status;
  }


  send(channelName: string, param: string): void {
    this.stomp.send(channelName, param);
  }
}
