
import { AppConstants } from '../constants';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

//import { MenuService } from './menu.service';
// import { HttpClient } from '@app/web.service';
import { ApiConstants } from '../constants';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { SuccessStatusMessage } from './success.service';
import { Subject, Observable, } from 'rxjs';



@Injectable()

export class CommonService {
  isConnectedToEcm = false;
  // isReportNavigate: Subject<any> = new Subject<any>();
  checkToolUpgrade: Subject<any> = new Subject<any>();
  public mergeLogWin: any;
  public isInstallConfigDialogVisible = false;
  public installConfigSuccessDialogDuration = '60';
  isMachineConnected: Subject<any> = new Subject<any>();
  currentBuildInfo;
  updateConfigEquipInProgress: Subject<any> = new Subject<any>();
  syncStatus: any;
  isFileSyncInProgress: any;
  showAccountSelectionInPopup = false;
  resetMenuHighlightSub: Subject<any> = new Subject<any>();
  signoutPopup: Subject<any> = new Subject<any>();
  showAccChangeSavePopup = false;
  showSignoutConfirmation = false
  isSignoutClicked = false;
  displaySpinner = false;
  isValidLicense = false;
  isTokenAvailable: any;
  routeHandler: Subject<any> = new Subject<any>();
  skipTestValidation = false;
  isVIMSConverterLoaded = (environment.applicationName === AppConstants.getConstants('VIMS_PC_APP_TITLE'));
  sCurrentBuildVer = environment.applicationName + ' is loading...';
  isVimsConfigFileAvailable = true;
  isEcmBusy = false;
  configData = {
    'isUpdateConfigInProgress': false,
    'editedData': {}
  };
  settingActiveTab = false;
      // Observable string sources
      private readonly componentMethodCallSource = new Subject();
      // Observable string streams
    componentMethodCalled$ = this.componentMethodCallSource.asObservable();

  constructor( private http: HttpClient, private router: Router,
    private readonly successStatusMessage: SuccessStatusMessage,
    private store: Store<any>) {
  }


  public setEcmBusyStatus(bool) {
    this.isEcmBusy = bool;
    this.updateConfigEquipInProgress.next(bool);
  }

 
  public getEcmBusyStatus(): boolean {
    return this.isEcmBusy;
  }

  invokeConnectedMacPropertiesAPI(): Observable<object> {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('connectedMachineProperties'));
  }

  navigateToDashboard() {
    // this.menuService.getMenuItems().subscribe(response => {
    //   response.map(menuItem => {
    //     if (menuItem.navigateToDashboard && this.router.url === menuItem.routeLink) {
    //       this.router.navigate(['/dashboard']);
    //     }
    //   })
    // })
  }

  clearStore(types: Array<any>): void {
    types.forEach((type) => {
      const action = {
        type: type,
        payload: {
          data: null
        }
      }
      this.store.dispatch(action);
    });
  }


  getToolVersion(): Observable<object> {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('getToolVersion'));
  }

  getSessionValidity(): Observable<object> {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('getSessionExpiryInfo'));
  }

  clearUserSession(): Observable<any> {
    this.isValidLicense = false;
    return this.http.delete(environment.baseUrl + ApiConstants.getAPI('clearLoginCredentials')); // clearLoginCredentials
  }
  
  getShortHandName(fullName, length): string {
    const splitName = fullName.split(' ');
    let shortName = '';
    splitName.forEach((item, index) => {
      if (index < length) {
        shortName += item.charAt(0).toUpperCase();
      }
    });
    return shortName;
  }
 
  getPreferedDateFormat(): string {
    const preferences = JSON.parse(localStorage.getItem(AppConstants.getConstants('USER_PREFERENCE')));
    return preferences.toolSettings.dateFormat.toString();
  }
 
  updatePreferredDateFormat(): string {
    let preferredDateFormat = this.getPreferedDateFormat();
    preferredDateFormat = preferredDateFormat.replace('yyyy', 'yy');
    preferredDateFormat = preferredDateFormat.replace('MM', 'mm');
    return preferredDateFormat;
  }
  
  checkIsConfigInstalled(): Observable<object> {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('isConfigInstalled'));
  }

  
  machineConnection(event) {
    this.isMachineConnected.next(event);
  }
  get isMacConnected$() {
    return this.isMachineConnected.asObservable();
  }

  
  setFileSyncStatus(syncStatus: any) {
    this.syncStatus = syncStatus;
  }


  getFileSyncStatus() {
    return this.syncStatus;
  }


  setFileSyncProgress(syncProgress: any) {
    this.isFileSyncInProgress = syncProgress;
  }

  getFileSyncProgress() {
    return this.isFileSyncInProgress;
  }

  resetMenuHighlight() {
    this.resetMenuHighlightSub.next(true);
  }

  showSignoutPopup() {
    this.signoutPopup.next(true);
  }


  isToolUpdateAvailable() {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('isToolUpdateAvaliable'));
  }

 
  initRouterEvents(): void {
    this.router.events.subscribe((event) => {
      switch (event.constructor.name) {
        case AppConstants.ROUTES_EVENTS['NAVIGATION_START']:
          console.log('NAVIGATION_START');
          break;
        case AppConstants.ROUTES_EVENTS['NAVIGATION_END']:
          this.routeHandler.next(event);
          break;
        case AppConstants.ROUTES_EVENTS['NAVIGATION_ERROR']:
          console.log('NAVIGATION_ERROR');
          break;
      }
    })
  }

  /* Pop up Common Service*/
  callComponentMethod(value: boolean) {
    this.componentMethodCallSource.next(value);
  }

    showpopup(type, msg) {
    switch (type) {
      case 'success':
        this.successStatusMessage.statusSuccess(msg);
        break;
    }
  }
}
