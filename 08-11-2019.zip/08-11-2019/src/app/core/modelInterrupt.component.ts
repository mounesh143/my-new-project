import { ElementRef } from '@angular/core';
import { Component } from '@angular/core';
import { ModelInterruptService } from './modelInterrupt.service';


@Component({
  selector: 'app-modelinterrupt',
  template: `
  <div *ngFor="let alert of modelInterruptService.alerts">
  <p-dialog [header]="alert.title" [modal]="true" width="500" [responsive]="true" [closable]="false" *ngIf="alert.isVisible"
    [(visible)]="alert.isVisible" [draggable]="false" (onShow)="onShow(alert)">
    <div class="dialog_content">
      <div [innerHtml]="alert.message" [id]="alert.id"></div>
      <div class="btn_container">
        <button id="ok_btn" class="btn cat_btn" type="button" pButton (click)="onClickOkBtn(alert)">{{alert.btnText}}</button>
      </div>
    </div>
  </p-dialog>
</div>


<p-growl [(value)]="modelInterruptService.toast"></p-growl>


  `,
  styles: ['']
})
export class ModelInterruptComponent {

  constructor(public modelInterruptService: ModelInterruptService, public eleRef: ElementRef) { }

  /**
   * @description handles the event while alert is shown
   * @author Vigneswar Chelliah
   * @param {any} alert
   * @memberof ModelInterruptComponent
   */
  onShow(alert): void {
    const linkEle = this.eleRef.nativeElement.querySelector('#' + alert.id + ' #link_id');
    const btnEle = this.eleRef.nativeElement.querySelector('#ok_btn'); // '#' + alert.id +
    this.bindEventListeners(linkEle || btnEle);
  }

  /**
   * @description Used to handle click ok btn
   * @author Vigneswar Chelliah
   * @param {any} obj
   * @memberof ModelInterruptComponent
   */
  onClickOkBtn(obj) {
    this.modelInterruptService.removeAlert(obj, 'btn');
  }

  /**
   * @description Used to register event listener on clicking link
   * @author Vigneswar Chelliah
   * @param {any} element
   * @memberof ModelInterruptComponent
   */
  bindEventListeners(element): void {
    element.addEventListener('click', (event) => {
      const activeAlertId = event.target.parentElement.id;
      const activeAlert = this.modelInterruptService.alerts.filter((alert) => alert.id === activeAlertId)[0];
      (activeAlert) ? this.modelInterruptService.removeAlert(activeAlert, 'link') : console.log('not valid alert');
    })
  }
}
