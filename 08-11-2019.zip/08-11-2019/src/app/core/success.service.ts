

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class SuccessStatusMessage {
  statusSuccessMsg = '';
  testerrMsg = new Subject();
  testerrMsgobs = this.testerrMsg.asObservable();
  constructor() {}

  statusSuccess(statusCodeErrStr) {
    this.statusSuccessMsg = statusCodeErrStr;
    this.testerrMsg.next(statusCodeErrStr);
  }
}
