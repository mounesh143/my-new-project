import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { MergeComponent } from './merge/merge.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { appReducers } from '@app/app.reducers';
import { MergeService } from './merge/merge.service';
import {CommonService} from './core/common.service';
import {  MenuService} from  './core/menu.service';
import {   ModelInterruptService } from './core/modelInterrupt.service';
import { HttpModule, Http, ConnectionBackend, BaseRequestOptions, ResponseOptions, Response } from '@angular/http';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
//import { StompMsgService } from './core/stomp.service';
import { StompService } from 'ng2-stomp-service';
import { SettingsService } from './tools-setting/settings.service';
import { DatabaseManagementService } from './db-management/database-management-service';
import {  inject, ComponentFixture } from '@angular/core/testing';
import { from } from 'rxjs/observable/from';
import { StomMsgModule } from './core';
import { SelectButtonModule, DialogModule, TabViewModule, CheckboxModule, OverlayPanelModule, CalendarModule, AccordionModule, DropdownModule, RadioButtonModule, ProgressBarModule } from 'primeng/primeng';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { MergeModule } from './merge/merge.module';
import { AppRoutingModule } from './app.routing.module';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ToolsSettingComponent } from './tools-setting/tools-setting.component';
import { DatabaseManagementSettingsComponent } from './db-management/database-management-settings.component';
import { LoggingSettingsComponent } from './tools-setting/logging-settings/logging-settings.component';
import { MergeSettingsComponent } from './tools-setting/merge-settings/merge-settings.component';
import { CatTogglebuttonComponent } from './tools-setting/cat-togglebutton.component';
import { ReportsSettingsComponent } from './tools-setting/reports-settings/reports-settings.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { BackupRestoreSettingsComponent } from './db-management/backup-restore-settings/backup-restore-settings.component';
import { DatabaseDeleteSettingsComponent } from './db-management/database-delete-settings/database-delete-settings.component';
//import { MergeModule } from './merge/merge.module';
import { DataTableModule, SharedModule,  PaginatorModule,  ToggleButtonModule,  AutoCompleteModule } from 'primeng/primeng';
describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        HeaderComponent,
        LoginComponent,
        HomeComponent,
        ToolsSettingComponent,
        DatabaseManagementSettingsComponent,
        LoggingSettingsComponent,
        MergeSettingsComponent,
        CatTogglebuttonComponent,
        ReportsSettingsComponent,
        DashboardComponent,
        BackupRestoreSettingsComponent,
        DatabaseDeleteSettingsComponent
      ],
      imports: [
        DataTableModule, SharedModule,  PaginatorModule,  ToggleButtonModule,  AutoCompleteModule,
        HttpClientModule,RouterTestingModule,
        SelectButtonModule,
        ProgressBarModule,
        DropdownModule,
        DialogModule,
        TabViewModule,
        CheckboxModule,
        OverlayPanelModule,
        CalendarModule,
        CheckboxModule,
        AccordionModule,
        BrowserModule,FormsModule,RouterModule,HttpModule,HttpClientModule,ReactiveFormsModule,
        MergeModule,StoreModule.forRoot(appReducers),AppRoutingModule,TabViewModule,CommonModule,RadioButtonModule
        
        
      ],
      providers:[ { provide: APP_BASE_HREF, useValue : '/' }  ]
    }).compileComponents();
  }));
  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
  it(`should have as title 'app'`, async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('app');
  }));
  xit('should render title in a h1 tag', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Welcome to JackFruit Project !!!');
  }));
});
