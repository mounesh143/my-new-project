// import { TestBed, async } from '@angular/core/testing';
// import { MergeComponent } from './merge.component';
// import { MergeService } from './merge.service';
// import { CommonService } from '@app/common.service';
// import { HttpClient, HttpClientModule } from '@angular/common/http';
// import { Router, RouterModule } from '@angular/router';
// import { RouterTestingModule } from '@angular/router/testing';
// import { StoreModule } from '@ngrx/store';
// import { appReducers } from '@app/app.reducers';

// //import { MergeModule } from './merge/merge.module';

// describe('MergeComponent', () => {
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [
//         MergeComponent,
       
//       ],
//       imports: [
//         HttpClientModule,RouterTestingModule,
//         //StoreModule.forRoot(appReducers)
        
//       ],
//       providers:[ MergeService,CommonService  ]
//     }).compileComponents();
//   }));
//   it('should create the app-merge', async(() => {
//     const fixture = TestBed.createComponent(MergeComponent);
//     const app = fixture.debugElement.componentInstance;
//     expect(app).toBeTruthy();
//   }));
//   // it(`should have as title 'app'`, async(() => {
//   //   const fixture = TestBed.createComponent(MergeComponent);
//   //   const app = fixture.debugElement.componentInstance;
//   //   expect(app.title).toEqual('app-merge');
//   // }));
  
// });
