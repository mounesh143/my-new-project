import {
  StompMsgService, CommonService, MenuService, ModelInterruptService,
} from '../core/index';
import { MergeStoreActions } from '../reducers/merge.reducer';

import { Component, OnInit, ViewEncapsulation, Input, ViewChild, OnDestroy, EventEmitter, Output, ElementRef } from '@angular/core';
import { MergeService } from './merge.service';
import { AppConstants, ApiConstants } from '../constants';
import { DomSanitizer } from '@angular/platform-browser';
import { Paginator } from 'primeng/primeng';
import { NgZone } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { AuthenticationService } from '@app/Services/authentication.service';

import { FILE } from 'dns';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-merge',
  templateUrl: './merge.component.html',
  styleUrls: ['./merge.component.scss']
})

export class MergeComponent implements OnInit, OnDestroy {
  @ViewChild('logFiles')
  logFiles: ElementRef;
  inputControl = {
    'isMergeInProgress': false,
    'tgl_btn_on_label': 'Cancel',
    'tgl_btn_off_label': 'Merge',
    'availableFiles': [],
    'isMergeClicked': false,
    'isDeleteClicked': false,
    'selectedFileTypes': [],
    'overallProgress': 0,
    'displayMergeResponse': false,
    'isAutoMergeEnabled': false,
    'mergeTableHeight': '',
    'mergeTableTopBlockHeight': 360,
    'mergeTableBottomBlockHeight': 105,
    'rowsCount': 12,
    'totalRecordsCount': 1,
    'mergeLogPath': '',
    'mergeCommonFile': '\\MergeLog.out',
    'autoMergeStatus': '',
    'pages': [],
    'currentPage': 1,
    'isRefreshClicked': false,
    'statusCompleted': 'Completed',
    'statusFailed': 'Failed',
    'isSelectAllChecked': false
  };

  fileContent: any;
  autoMergeSubscription: any;
  autoMergeMsgSubscription: any;
  manualMergeSubscription: any;
  mergeStompSubscription;
  clickedFromMenuDownload = true;
  display: boolean = false;
  mergeStore: Observable<any>;
  mergeStoreSubscription: Subscription;

  constructor(private commonService: CommonService, private mergeService: MergeService,
    private authService: AuthenticationService,
    private stomp: StompMsgService, private zone: NgZone, private sanitizer: DomSanitizer,
    private modelInterruptService: ModelInterruptService) {
    this.mergeStore = this.mergeService.mergeStore;
    (!this.commonService.skipTestValidation) ? this.initStompChannels() : console.log('skip stomp channel init for Test run')
    this.getOverallMergeProgress();
  }



  ngOnInit() {
    this.mergeStoreSubscription = this.mergeStore.subscribe((storeData) => {
      if (storeData.data) {
        this.inputControl = storeData.data;
        this.updateAutoMergeStatus();
        this.refreshMergeTable();
      } else {
        this.getMergeStatusList(0, AppConstants.getConstants('DESC'), AppConstants.getConstants('MERGE_DEFAULT_COLUMN'));
      }
    });

    const userPreference = JSON.parse(localStorage.getItem(AppConstants.getConstants('USER_PREFERENCE')));
    this.inputControl['isAutoMergeEnabled'] = userPreference.toolSettings.isAutoMergeOn;
    this.inputControl['autoMergeStatus'] = (this.inputControl['isAutoMergeEnabled']) ? AppConstants.getConstants('ENABLED') :
      AppConstants.getConstants('DISABLED');
    this.getMergeLogFilePath();
    this.inputControl['mergeTableTopBlockHeigh'] = this.clickedFromMenuDownload ? 0 : 360;

  }

  updateAutoMergeStatus(): void {
    const userPreference = JSON.parse(localStorage.getItem(AppConstants.getConstants('USER_PREFERENCE')));
    this.inputControl['isAutoMergeEnabled'] = true;//userPreference.toolSettings.isAutoMergeOn;
    this.inputControl['autoMergeStatus'] = (this.inputControl['isAutoMergeEnabled']) ? AppConstants.getConstants('ENABLED') :
      AppConstants.getConstants('DISABLED');
  }


  displayPage(event) {
    const pagesArraySize = Math.ceil(this.inputControl['totalRecordsCount'] / this.inputControl['rowsCount']);
    this.inputControl['pages'] = Array(pagesArraySize).fill(0).map((x, i) => (i + 1));
  }
  refreshMergeTable(): void {
    const pageObj = {
      // 'page': this.inputControl['currentPage'] - 1
      'page': 0  // as per #9110 user need t0 land on first page when navigate form other tab
    };
    this.onPageChange(pageObj);
  }


  getMergeLogFilePath() {
    this.mergeService.getSettingsPreferences().subscribe((settingsData) => {
      console.log(settingsData)
      const logPath = settingsData['defaultPaths']['settingsFilePathsUIBean'];
      logPath.map((eachGroup) => {
        eachGroup.paths.map((eachItem) => {
          if (eachItem.id === 'MergeFailureLog') {
            this.inputControl['mergeLogPath'] = eachItem.path;
            /* const mergeCommonFile = this.inputControl['mergeLogPath'] + '\\MergeLog.out';
            this.inputControl['mergeCommonFile'] = mergeCommonFile; */
          }
        })
      })
    }, (error) => { })
  }

  /* istanbul ignore next */
  initStompChannels(): void {
    this.stomp.connect().then(() => {
      setTimeout(() => {
        this.subscribeToAutoMergeProgress();
        this.subscribeMergeStatusStompChannel();
        this.subscribeToAutoMergeMessage();
      }, 1000);
    })
  }

  toggleMergeCancel(event) {
    this.inputControl['overallProgress'] = 0;
    this.inputControl['isMergeInProgress'] = this.inputControl['isRefreshClicked'] = true;
    (event.checked) ? this.mergeFiles() : this.cancelMerge();
  }

  cancelMerge() {
    this.inputControl.isMergeInProgress = false;
    this.mergeService.cancelMerge().subscribe((res) => {
    }, (err) => {
      this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_ERROR'),
        'Unable to cancel the ongoing merge', true); // temp fix
    });
  }

  mergeFiles() {
    this.inputControl['selectedFileTypes'] = this.inputControl['selectedFileTypes'].filter((file) =>
      file.fileStatus !== this.inputControl['statusCompleted'] && file.fileStatus !== this.inputControl['statusFailed']);
    if (this.inputControl['isSelectAllChecked']) {
      this.mergeService.postAllFilesToMerge().subscribe((res: any) => {
        this.handleManualMergeResponse(res);
      }, (err) => {
        this.inputControl['isMergeClicked'] = false;
      });
    } else {
      this.mergeService.postFilesToMerge(this.inputControl['selectedFileTypes']).subscribe((res: any) => {
        this.handleManualMergeResponse(res);
      }, (err) => {
        this.inputControl['isMergeClicked'] = false;
      });
    }
  }

  handleManualMergeResponse(res) {
    this.inputControl['isMergeClicked'] = false;
    this.inputControl['displayMergeResponse'] = true;
    this.inputControl['isSelectAllChecked'] = false;
    this.inputControl['isMergeInProgress'] = false; // added when manual merge response back need to reset the value
    this.handleToast(res);
    this.inputControl['selectedFileTypes'] = [];
  }

  handleToast(res) {
    const toastSeverity = res.success ? AppConstants.getConstants('GROWL_SUCCESS') : AppConstants.getConstants('GROWL_ERROR');
    this.modelInterruptService.displayToast(toastSeverity, res.result, true);
  }

  /* istanbul ignore next */
  subscribeToAutoMergeProgress(): void {
    this.autoMergeSubscription = this.stomp.getStomp().subscribe(ApiConstants.getAPI('mergeChannel'),
      this.getOverAllMergeProgressStatus.bind(this));
  }

  getOverAllMergeProgressStatus(overallProgressObj) {
    this.inputControl.isMergeInProgress = true;
    this.inputControl['overallProgress'] = Math.round(overallProgressObj.mergePercentage);
  }

  getOverallMergeProgress() {
    this.mergeService.getOverallMergeProgress().subscribe((response) => {
      this.handleOverAllMergeProgessSuccess(response);
    })
  }

  handleOverAllMergeProgessSuccess(response) {
    this.inputControl['overallProgress'] = Math.round(response);
    // when overall progess is 100 or 0 no merge happening need to reset the values
    if (this.inputControl.overallProgress === 100 || this.inputControl.overallProgress === 0) {
      this.inputControl.isMergeClicked = false;
      this.inputControl.isMergeInProgress = false;
    }
  }

  /* istanbul ignore next */
  subscribeToAutoMergeMessage(): void {
    this.autoMergeMsgSubscription = this.stomp.getStomp().subscribe(ApiConstants.getAPI('autoMergeChannel'), (res) => {
      //const mergeMessage = mergeMessageObj.message;
      if (res.result !== '') {
        this.handleToast(res);
        //  this.inputControl['displayMergeResponse'] = true;
        //  this.modelInterruptService.displayToast(AppConstants.getConstants('GROWL_SUCCESS'), mergeMessage, true);
      }
    });
  }

  deleteFiles() {
    this.inputControl['isMergeInProgress'] = false;
    this.inputControl['isRefreshClicked'] = true;
    this.inputControl['selectedFileTypes'] = this.inputControl['selectedFileTypes'].filter((file) =>
      file.fileStatus !== this.inputControl['statusCompleted'] && file.fileStatus !== this.inputControl['statusFailed']);
    if (this.inputControl['isSelectAllChecked']) {
      this.mergeService.deleteAllFiles().subscribe((res: any) => {
        this.handleDeleteFilesResponse(res);
      }, (err) => {
        this.inputControl['isDeleteClicked'] = false;
      });
    } else {
      this.mergeService.deleteFiles(this.inputControl['selectedFileTypes']).subscribe((res: any) => {
        this.handleDeleteFilesResponse(res);
      }, (err) => {
        this.inputControl['isDeleteClicked'] = false;
      });
    }
  }

  handleDeleteFilesResponse(res): void {
    this.inputControl['isDeleteClicked'] = false;
    this.inputControl['isSelectAllChecked'] = false;
    this.handleToast(res);
    this.inputControl['selectedFileTypes'] = [];
    const pageNo = this.inputControl['currentPage'] === 1 ? 0 : this.inputControl['currentPage'];
    this.getMergeStatusList(pageNo, AppConstants.getConstants('DESC'), AppConstants.getConstants('MERGE_DEFAULT_COLUMN'));
  }

  /* istanbul ignore next */
  onPageChange(event) {
    let pageToFetch = (event.page === undefined || event.page === null) ? parseInt(event, 10) - 1 : event.page;
    // if entered pagenumber is not available then take user to last page as per AC
    if (this.inputControl['pages'].length > 0) {
      pageToFetch = this.inputControl['pages'].indexOf(parseInt(this.inputControl['currentPage'].toString(), 10)) === -1 ?
        this.inputControl['pages'][this.inputControl['pages'].length - 1] - 1 : pageToFetch;
    }
    this.inputControl['currentPage'] = pageToFetch + 1;
    // this.tablePaginator._first = pageToFetch * this.inputControl['rowsCount'];

    this.getMergeStatusList(pageToFetch, AppConstants.getConstants('DESC'), AppConstants.getConstants('MERGE_DEFAULT_COLUMN'));
  }


  getMergeStatusList(pageNo: number = 0, sortOrder: string = 'DESC', sortColumn: string = 'downloadDateTime') {
    /* const response = MergeMock.getMergeMock();
    this.inputControl['availableFiles'] = response.filesList;
    this.updateTotalPages(response.totalElements); */
    this.mergeService.getMergeStatusList(pageNo.toString(), this.inputControl['rowsCount'].toString(), sortOrder, sortColumn).
      subscribe((response) => {
        this.handleGetMergeFilesApiResponse(response);
      });
  }

  handleGetMergeFilesApiResponse(response) {
    this.inputControl['availableFiles'] = response.filesList;
    this.updateTotalPages(response.totalElements);
    this.inputControl['isRefreshClicked'] = false;
    if (this.inputControl['isSelectAllChecked']) {
      this.inputControl['selectedFileTypes'] = this.inputControl['availableFiles'];
    }
  }

  subscribeMergeStatusStompChannel() {
    this.mergeStompSubscription = this.stomp.getStomp().subscribe(ApiConstants.getAPI('fileMergeStatusChannel'), (response) => {
      this.zone.run(() => {
        this.handleGetMergeFilesApiResponse(response);
      });
    })
  }


  updateTotalPages(count) {
    this.inputControl['totalRecordsCount'] = count;
    const pagesArraySize = Math.ceil(this.inputControl['totalRecordsCount'] / this.inputControl['rowsCount']);
    this.inputControl['pages'] = Array(pagesArraySize).fill(0).map((x, i) => (i + 1));
  }
  openMergeLog(param?, createdDate?) {
    (param) ? param.hide() : console.log(param, ' is undefined');
    const mergeLogFile = (createdDate) ? (createdDate.split('T')[0] === String(new Date().toISOString().split('T')[0])) ?
      '' : ('.' + createdDate.split('T')[0]) : '';
    let file
    if (mergeLogFile !== '') {
      file = 'MergeLog.out' + mergeLogFile;
    } else {
      file = 'MergeLog.out';
    }
    console.log(file)


    this.mergeService.getFileReader(file).subscribe(data => {
      this.fileContent = data;
    })


    this.logFiles.nativeElement.style.display = 'block';
  }

  closeModal() {
    this.logFiles.nativeElement.style.display = 'none';
  }



  refreshTable() {
    this.inputControl['isRefreshClicked'] = true;
    this.getMergeStatusList(this.inputControl['currentPage'] - 1, AppConstants.getConstants('DESC'),
      AppConstants.getConstants('MERGE_DEFAULT_COLUMN'));
  }

  sortColumn(event) {
    const orderToFetch = (event.order === 1) ? AppConstants.getConstants('DESC') : AppConstants.getConstants('ASC');
    this.getMergeStatusList(this.inputControl['currentPage'] - 1, orderToFetch, event.field);
  }

  getStatusStyleClass(rowData: any) {
    const userPreference = JSON.parse(localStorage.getItem(AppConstants.getConstants('USER_PREFERENCE')));
    if ((rowData.fileStatus === 'Completed' || rowData.fileStatus === 'Failed')) {
      return 'Disable_class'
    }
  }

  onRowSelectFilterCompleteStatus(e) {
    setTimeout(() => {
      this.inputControl['selectedFileTypes'] = this.inputControl['selectedFileTypes'].filter((data) =>
        data.fileStatus !== this.inputControl['statusCompleted'] && data.fileStatus !== this.inputControl['statusFailed']);
    })
  }

  selectAllFiles(e) {
    const yetToMergeList = this.inputControl['availableFiles'].filter((data) =>
      data.fileStatus !== this.inputControl['statusCompleted'] && data.fileStatus !== this.inputControl['statusFailed']);
    if (yetToMergeList.length === 0) {
      this.inputControl['selectedFileTypes'] = [];
    } else {
      this.inputControl['isSelectAllChecked'] = e.checked;
    }
  }


  onKeyUp($event, currentPage) {
    ($event.keyCode === AppConstants.getConstants('ENTER_KEY_CODE')) ? this.onPageChange(currentPage) :
      console.log('Merge Pagination')
  }


  ngOnDestroy() {
    this.mergeStompSubscription ? this.mergeStompSubscription.unsubscribe() : console.log('stomp subscription handled');
    this.autoMergeSubscription ? this.autoMergeSubscription.unsubscribe() : console.log('stomp subscription handled');
    this.autoMergeMsgSubscription ? this.autoMergeMsgSubscription.unsubscribe() : console.log('stomp subscription handled');
    this.manualMergeSubscription ? this.manualMergeSubscription.unsubscribe() : console.log('stomp subscription handled');
    this.mergeService.updateStore(this.inputControl, MergeStoreActions.SET_MERGE_STATE);
    this.mergeStoreSubscription ? this.mergeStoreSubscription.unsubscribe() :
      console.log('store subscription handled at merge component');
  }
}
