import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http'
// import { DialogModule } from 'primeng/components/dialog/dialog';
import { MergeComponent } from './merge.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MergeService } from './merge.service';
import { FormsModule } from '@angular/forms';
import { RouterModule} from '@angular/router';
import { DataTableModule,DialogModule, SharedModule, CheckboxModule, PaginatorModule, TabViewModule, ToggleButtonModule, ProgressBarModule, OverlayPanelModule, AutoCompleteModule } from 'primeng/primeng';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot([]),
    DataTableModule,
    SharedModule,
    CheckboxModule,
    PaginatorModule,
    TabViewModule,
    DialogModule,
    ToggleButtonModule,
    ProgressBarModule,
    OverlayPanelModule,
    AutoCompleteModule,
    HttpClientModule,
    HttpModule,
    BrowserAnimationsModule,
    FormsModule,
  ],
  declarations: [MergeComponent],
  exports: [MergeComponent],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
  providers: [MergeService]
})
export class MergeModule { }
