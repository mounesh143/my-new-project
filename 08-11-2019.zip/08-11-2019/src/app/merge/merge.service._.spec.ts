import { HttpModule } from '@angular/http';
import { TestBed, inject } from '@angular/core/testing';
import { MergeService } from './merge.service';

import { RouterTestingModule } from '@angular/router/testing';
import { StoreModule } from '@ngrx/store';
import { appReducers } from '@app/reducers/app.reducers';
import { Http, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { HttpClient, HttpClientModule } from '@angular/common/http';

describe('MergeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule,HttpClientModule,
         RouterTestingModule, StoreModule.forRoot(appReducers)],
      providers: [MergeService, HttpClient, MockBackend, BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        }]
    });
  });

  it('should be created', inject([MergeService], (service: MergeService) => {
    expect(service).toBeTruthy();
  }));

  it('should handle postFilesToMerge method',
    inject([MergeService], (service: MergeService) => {
      const filesToMerge = ['file1', 'file2'];
      service.postFilesToMerge(filesToMerge);
    }));

  it('should handle cancelMerge method',
    inject([MergeService], (service: MergeService) => {
      service.cancelMerge();
    }));

  it('should handle deleteFiles method',
    inject([MergeService], (service: MergeService) => {
      const filesToDelete = ['file1', 'file2'];
      service.deleteFiles(filesToDelete);
    }));
});
