// import { HttpClient } from '@app/web.service';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { ApiConstants } from '../constants';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions} from '@angular/http';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';

@Injectable()
export class MergeService {

  // Redux based variables
  mergeStore: Observable<any>;

  constructor(private http: HttpClient, private store: Store<any>) {
    this.mergeStore = store.select(_store => _store.mergeStore);
  }


  postFilesToMerge(filesToMerge: any) {
    const postFilesToMergeUrl = environment.baseUrl + ApiConstants.getAPI('mergeFiles');
    return this.http.put(postFilesToMergeUrl, filesToMerge);
  }

  postAllFilesToMerge() {
    const postAllFilesToMergeUrl = environment.baseUrl + ApiConstants.getAPI('mergeAllFiles');
    return this.http.put(postAllFilesToMergeUrl, '');
  }

  cancelMerge() {
    const cancelMergeUrl = environment.baseUrl + ApiConstants.getAPI('cancelMerge');
    return this.http.get(cancelMergeUrl);
  }

  deleteFiles(filesToDelete) {
    const deleteMergeUrl = environment.baseUrl + ApiConstants.getAPI('deleteFiles');
    return this.http.put(deleteMergeUrl, filesToDelete);
  }

  deleteAllFiles() {
    const deleteAllMergeUrl = environment.baseUrl + ApiConstants.getAPI('deleteAllFiles');
    return this.http.put(deleteAllMergeUrl, '');
  }

  getMergeStatusList(length, offset, sortType, sortField) {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('getMargeStatusList') +
      '?length=' + length + '&offset=' + offset + '&sortType=' + sortType + '&sortField=' + sortField);
  }

  getSettingsPreferences() {
    console.log('called');
    const getSettingsUrl = environment.baseUrl + ApiConstants.getAPI('getSettings');
    return this.http.get(getSettingsUrl);
  };

  getOverallMergeProgress() {
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('getOverallMergeProgress'));
  }

  updateStore(data, type): void {
    const action = {
      type: type,
      payload: {
        data: data
      }
    }
    this.store.dispatch(action);
  }

  getFileReader(fileName){
    //logFIles
    return this.http.get(environment.baseUrl + ApiConstants.getAPI('logFIles'),{
      params: {
        fileName: fileName,
        
      },
      responseType: 'text'
    },);
  }

 
}
