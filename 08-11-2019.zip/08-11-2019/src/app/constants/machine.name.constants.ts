export class MachineNameConstants {

    /* istanbul ignore next */
    public static getMachineName(machineName): string {
        const _nameObject: Object = {
            'TPMS': 'tpms',
            'VIMS': 'vims',
            'A4_MAIN': 'a4 main module',
            'A4_APP': 'a4 app module',
            'ABL_1M': 'abl 1m',
            'ABL_2M': 'abl 2m',
            'PCS': 'pcs',
            'A4_TPMS': 'a4 tpms module',
            'A4_HIM': 'a4 him'
        }
        return _nameObject[machineName];
    }
}
