import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../Services/authentication.service';
import { Router } from '@angular/router';
import { SettingsService } from '@app/tools-setting/settings.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  userInfo={
    role:''
  };
  constructor(private authentication:AuthenticationService,private settingsService:SettingsService, 
    private router: Router) { }

  ngOnInit() {
   
    this.userInfo = this.authentication.getLoginInfoDetails();
  }
  logOut(){
    this.router.navigate(['login']);
    this.authentication.logOut().subscribe( data =>{
            sessionStorage.removeItem('userName')
            localStorage.removeItem('userInfo')
           
    },
    err=>{ sessionStorage.removeItem('userName')
    localStorage.removeItem('userInfo')
   
    console.log(err)});
  }


  getRoleBaseAuth(){
    if(this.userInfo['role'] === undefined){
      return false;
    }
    else if(this.userInfo['role']==='Developer' || this.userInfo['role']==='Customer' ){
      return true;
    }
    else{
      return false;
    }

    
  }
}
