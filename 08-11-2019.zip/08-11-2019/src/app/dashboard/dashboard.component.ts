import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  
})
export class DashboardComponent implements OnInit {

  loading:true
  userDeatils = JSON.parse(localStorage.getItem('userInfo'));
  dashboardUrl;
  constructor(private sanitizer: DomSanitizer) { }

  ngOnInit() {
    if(this.userDeatils !== undefined){
      let dashBoardUrl = 'http://localhost:8081/viz#/' + '?token='+ this.userDeatils['token'] + '&oid='+ this.userDeatils['oid'];
      this.dashboardUrl = this.sanitizer.bypassSecurityTrustResourceUrl(dashBoardUrl);
    }
    
  }
 
}
