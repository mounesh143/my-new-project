import { Component, ViewChild, ElementRef, Renderer2, transition, animate, style, trigger, ChangeDetectorRef } from '@angular/core';
import { SuccessStatusMessage } from '@app/success.service';
import { CommonService } from '@app/common.service';

import { startWith, delay } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('fadeInOut', [
      transition(':enter', [   // :enter is alias to 'void => *'
        style({opacity:0}),
        animate(500, style({opacity:1})) 
      ]),
      transition(':leave', [   // :leave is alias to '* => void'
        animate(500, style({opacity:0})) 
      ])
    ])
  ]
})
export class AppComponent {
  title = 'app';
  @ViewChild('successModal') private  successModal: ElementRef;
  successMessage = '';
  constructor(private  successStatusMessage: SuccessStatusMessage,
    private commonService: CommonService,
    private  renderer: Renderer2,
    private cdRef: ChangeDetectorRef
  ) {
    this.successStatusMessage.testerrMsgobs
      .pipe(
        startWith(''),
        delay(0)
      )
      .subscribe(value => {
        if (value !== '') {
          this.successMessage = value;
          this.closeOpenModal('successModal', true);
          setTimeout(() => {
            this.closeOpenModal('successModal', false);
          }, 2000);
        } else {
          this.successMessage = '';
          this.closeOpenModal('successModal', false);
        }
      });
  }
  
  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  closeOpenModal(type, value) {
    const displayValue = value ? 'block' : 'none';
    switch (type) {

      case 'successModal':
        this.renderer.setStyle(
          this.successModal.nativeElement,
          'display',
          displayValue
        );
        break;
    }
  }
}
