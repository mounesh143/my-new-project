// import { OnBoardConfigureReducer, OnBoardConfigLayoutReducer } from '@app/onboardconfigure.reducer';
// import { DownloadReducer } from '@app/download.reducer';
import { MergeReducer } from '../reducers';
// import { RealTimeParamsReducer } from '@app/realtimeparams.reducer';

export const appReducers = {
    // onBoardConfig: OnBoardConfigureReducer,
    // onBoardConfigLayout: OnBoardConfigLayoutReducer,
    // downloadStore: DownloadReducer,
    mergeStore: MergeReducer
    // realtimeparamsStore: RealTimeParamsReducer
}
