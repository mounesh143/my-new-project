/**
 * @description Reducer function to deal with State of Merge component
 * @param {*} [state=[]]
 * @param {any} { type, payload }
 * @returns
 */
export function MergeReducer(state: any = [], { type, payload }) {
    switch (type) {
        case MergeStoreActions.SET_MERGE_STATE:
            return payload;
        /* case MergeStoreActions.GET_MERGE_STATE:
            break;
        case MergeStoreActions.PUT_MERGE_STATE:
            break; */
        default:
            return state;
    }
}

/**
 * @description Enum to list all available Actions for this Store
 * @export
 * @enum {number}
 */
export let MergeStoreActions = {
    'SET_MERGE_STATE': 'SET MERGE STATE',
    'GET_MERGE_STATE': 'GET MERGE STATE',
    'PUT_MERGE_STATE': 'PUT MERGE STATE',
}
