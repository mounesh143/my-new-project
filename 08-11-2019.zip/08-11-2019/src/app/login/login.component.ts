import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { AuthenticationService } from '../Services/authentication.service';
import { first } from 'rxjs/operators';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SuccessStatusMessage } from '@app/success.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted:boolean = false;
  userName = '';
  password = '';
  invalidLogin:boolean = false;
  errorMsg :string = null;
  loader:boolean = false;
  constructor(  private formBuilder: FormBuilder,
    private router: Router , private  successStatusMessage: SuccessStatusMessage,
    private loginservice: AuthenticationService) { }

  ngOnInit() {
      this.loginForm = this.formBuilder.group({
       username: ['', Validators.required],
      password: ['', Validators.required]
    });
 
  }

 onSubmit() {
  if(this.userName === ''  ||  this.password === '')
      {
       this.errorMsg = "Invalid Credentials";
        }
       this.submitted = true;

     if (this.loginForm.invalid) {
         return;  
     }
    this.loader = true;
    
    this.loginservice.authenticate(this.userName,  this.password)
      .pipe(first())
      .subscribe(
        ( res ) =>  {
          this.loader = false;
          console.log(res)
       if (res.status === 'VALID_USER') {
          this.router.navigate(['home/dashboard']);
          this.invalidLogin = false;
         } 
    else if(res.status === 'INVALID LICENSE') {
            this.errorMsg = "Jackfruit License Invalid"
            this.invalidLogin = true;
         }
         else{
          this.errorMsg = "Invalid Credentials";
          this.invalidLogin = true;
         }
           
        },
        error => {
          this.loader = false;
          this.showpopup('success', 'Internal Server Error');
            
        });
      }

      showpopup(type, errorMsg) {
        switch (type) {
          case 'success':
            this.successStatusMessage.statusSuccess(errorMsg);
            break;
         
        }
      }
}