import { async, ComponentFixture, TestBed, fakeAsync ,tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms'
import { Router } from '@angular/router';
import { Location } from "@angular/common";


import { LoginComponent } from './login.component';
import { AuthenticationService } from '../Services/authentication.service';
import { AppRoutingModule } from '../app.routing.module';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { HomeComponent } from '@app/home/home.component';
import { MergeComponent } from '@app/merge/merge.component';
import { DatabaseManagementSettingsComponent } from '@app/db-management/database-management-settings.component';
import { ToolsSettingComponent } from '@app/tools-setting/tools-setting.component';
import { HeaderComponent } from '@app/header/header.component';
import { DataTableModule,DialogModule, SharedModule, CheckboxModule, PaginatorModule, TabViewModule, ToggleButtonModule, ProgressBarModule, OverlayPanelModule, AutoCompleteModule, RadioButtonModule, CalendarModule, SelectButtonModule, DropdownModule, AccordionModule } from 'primeng/primeng';
import { DatabaseDeleteSettingsComponent } from '@app/db-management/database-delete-settings/database-delete-settings.component';
import { BackupRestoreSettingsComponent } from '@app/db-management/backup-restore-settings/backup-restore-settings.component';
import { LoggingSettingsComponent } from '@app/tools-setting/logging-settings/logging-settings.component';
import { MergeSettingsComponent } from '@app/tools-setting/merge-settings/merge-settings.component';
import { CatTogglebuttonComponent } from '@app/tools-setting/cat-togglebutton.component';
import { ReportsSettingsComponent } from '@app/tools-setting/reports-settings/reports-settings.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let el: HTMLElement;
  let router: Router;
  let location: Location;
 let  username ;
  let password ;
  let errorMsg

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [    HeaderComponent,
        LoginComponent,
        HomeComponent,
        MergeComponent ,
        ToolsSettingComponent,
        DatabaseManagementSettingsComponent,
        LoggingSettingsComponent,
        MergeSettingsComponent,
        CatTogglebuttonComponent,
        ReportsSettingsComponent,
        DashboardComponent,
        BackupRestoreSettingsComponent,
        DatabaseDeleteSettingsComponent   ],
      imports: [AppRoutingModule,ReactiveFormsModule,RouterTestingModule.withRoutes([]),HttpClientModule,FormsModule,
      DataTableModule,DialogModule, SharedModule, CheckboxModule, PaginatorModule, TabViewModule, ToggleButtonModule, ProgressBarModule, OverlayPanelModule, AutoCompleteModule,
      RadioButtonModule,CalendarModule,
      SelectButtonModule,
        ProgressBarModule,
        DropdownModule,
        DialogModule,
        TabViewModule,
        CheckboxModule,
        OverlayPanelModule,
        CalendarModule,
        CheckboxModule,
        AccordionModule,],
      providers: [           
        AuthenticationService,
      ]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    router = TestBed.get(Router)
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Should set submitted to true', async(() => {
    component.onSubmit();
    expect(component.onSubmit).toBeTruthy();
 }));

 it('should create Invalid Credentials', () => {
  expect(component.errorMsg).toBeNull();
});

 it('Form should be invalid', async(()=> {
  component.loginForm.controls['username'].setValue('');
  component.loginForm.controls['password'].setValue('');
  expect(component.loginForm.valid).toBeFalsy();
}));




it("username and password should not be null and undefined", function () {
  fixture.detectChanges();
  expect(component.userName).not.toBeUndefined();
  expect(component.userName).not.toBeNull();
  expect(component.password).not.toBeUndefined();
  expect(component.password).not.toBeNull();
  
});



});
