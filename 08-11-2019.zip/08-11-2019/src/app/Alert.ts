import { Subject } from 'rxjs/Rx';

export class Alert {
    private id: string;

    private message: string;

    private title: string;

    private btnText: string;

    private isVisible: boolean;

    private closeListener: Subject<any>;
    /**
     * Creates an instance of Alert.
     * @author Vigneswar Chelliah
     * @param {any} id
     * @param {any} message
     * @param {any} title
     * @param {any} btnText
     * @memberof ModelInterrupt
     */
    constructor(id, message, title, btnText) {
        this.id = id;
        this.message = message;
        this.title = title;
        this.btnText = btnText;
        this.closeListener = new Subject<any>();
    }

    /**
     * @description Used to return acknowlegement subject.
     * @author Vigneswar Chelliah
     * @returns {*}
     * @memberof ModelInterrupt
     */
    show(): Subject<any> {
        this.isVisible = true;
        return this.closeListener;
    }

    /**
     * @description Used to update the current alert message
     * @author Vigneswar Chelliah
     * @param {*} message
     * @memberof Alert
     */
    updateMessage(message): void {
        this.message = message;
    }
}
